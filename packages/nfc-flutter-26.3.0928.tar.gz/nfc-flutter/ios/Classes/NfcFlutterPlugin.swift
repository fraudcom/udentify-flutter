import udentify_core_flutter
import Flutter
import UIKit
import CoreNFC
import UdentifyCommons

final class ThreadSafeFlutterResult {
    private var result: FlutterResult?
    private let lock = NSLock()

    init(_ result: @escaping FlutterResult) {
        self.result = result
    }

    func send(_ value: Any?) {
        lock.lock()
        defer { lock.unlock() }
        guard let result = self.result else { return }
        self.result = nil
        DispatchQueue.main.async {
            result(value)
        }
    }
}

// Import UdentifyNFC framework if available
#if canImport(UdentifyNFC)
import UdentifyNFC
#endif

#if canImport(UdentifyNFC)
/// The SDK's own error name for a `TagError`, in the vocabulary the Android SDK reports (its `ERR_*`
/// string resources), so a failure reads the same on both platforms. Only the cases with a clear
/// counterpart are named; every other error returns `nil` and keeps the code it always had.
/// The pairing is by meaning, not taken from an SDK mapping table.
enum NfcSdkErrorName {
    static func code(for error: Error) -> String? {
        guard let tagError = error as? TagError else { return nil }
        switch tagError {
        case .PassiveAuthError: return "ERR_PASSIVE_AUTHENTICATION_FAILED"
        case .ActiveAuthenticationFailed: return "ERR_ACTIVE_AUTHENTICATION_FAILED"
        case .NFCNotSupported: return "ERR_NFC_READER_NOT_AVAILABLE"
        default: return nil
        }
    }
}
#endif

public class NfcFlutterPlugin: NSObject, FlutterPlugin {
    private var channel: FlutterMethodChannel?
    
#if canImport(UdentifyNFC)
    private var nfcReader: NFCReader?
    private var nfcLocator: NFCLocator?
    private var currentReadResult: ThreadSafeFlutterResult?
#endif
    
    
    public static func register(with registrar: FlutterPluginRegistrar) {
        let channel = FlutterMethodChannel(name: "nfc_flutter", binaryMessenger: registrar.messenger())
        let instance = NfcFlutterPlugin()
        instance.channel = channel
        registrar.addMethodCallDelegate(instance, channel: channel)

        // The in-call NFC screen takes its text bundle from the video call's LiveKYC options, so
        // it is read once when a call starts; publish the same bundle the standalone reader uses.
        UdentifyLiveKYCModuleSettings.nfcLocalizationBundle = {
            UdentifyLanguagePreference.localizedBundle(for: Bundle(for: NfcFlutterPlugin.self))
        }
    }
    
    public func handle(_ call: FlutterMethodCall, result: @escaping FlutterResult) {
        switch call.method {
        case "readPassport":
            readPassport(call: call, result: result)
        case "cancelReading":
            cancelReading(result: result)
        case "getNfcLocation":
            getNfcLocation(call: call, result: result)
        case "isNfcAvailable", "isNfcEnabled":
            result(NFCTagReaderSession.readingAvailable)
        case "checkPermissions":
            checkPermissions(result: result)
        case "requestPermissions":
            requestPermissions(result: result)
        default:
            result(FlutterError(code: "UNIMPLEMENTED", message: "Method not implemented", details: nil))
        }
    }
    
    // MARK: - NFC Methods
    
    private func readPassport(call: FlutterMethodCall, result: @escaping FlutterResult) {
#if canImport(UdentifyNFC)
        let threadSafeResult = ThreadSafeFlutterResult(result)
        
        guard let args = call.arguments as? [String: Any] else {
            threadSafeResult.send(FlutterError(code: "INVALID_ARGUMENTS", message: "Invalid arguments", details: nil))
            return
        }
        
        guard let documentNumber = args["documentNumber"] as? String,
              let dateOfBirth = args["dateOfBirth"] as? String,
              let expiryDate = args["expiryDate"] as? String,
              let transactionID = args["transactionID"] as? String,
              let serverURL = args["serverURL"] as? String else {
            threadSafeResult.send(FlutterError(code: "MISSING_PARAMETERS", message: "Missing required parameters", details: nil))
            return
        }
        
        let requestTimeout = args["requestTimeout"] as? Double ?? 10.0
        let chipAnticloneModeStr = args["chipAnticloneMode"] as? String
        let chipAnticloneMode: ChipAnticloneMode
        switch chipAnticloneModeStr {
        case "none":
            chipAnticloneMode = .none
        case "requireCA":
            chipAnticloneMode = .requireCA
        case "requireAA":
            chipAnticloneMode = .requireAA
        default:
            chipAnticloneMode = .auto
        }
        let isPassiveAuthEnabled = args["isPassiveAuthenticationEnabled"] as? Bool ?? true

        // Track the result for this in-flight read so cancelReading() can
        // resolve it explicitly (mirrors Android's guaranteed resolution).
        self.currentReadResult = threadSafeResult

        // Get the plugin bundle for localization
        let pluginBundle = UdentifyLanguagePreference.localizedBundle(for: Bundle(for: NfcFlutterPlugin.self))

        // Initialize NFCReader
        self.nfcReader = NFCReader(
            documentNumber: documentNumber,
            dateOfBirth: dateOfBirth,
            expiryDate: expiryDate,
            transactionID: transactionID,
            serverURL: serverURL,
            requestTimeout: requestTimeout,
            chipAnticloneMode: chipAnticloneMode,
            isPassiveAuthenticationEnabled: isPassiveAuthEnabled,
            bundle: pluginBundle,
            tableName: nil,
            logLevel: .warning
        )
        
        // Set delegate
        self.nfcReader?.sessionDelegate = self
        
        // Start reading
        self.nfcReader?.read { [weak self, threadSafeResult] passport, error, progress in
            DispatchQueue.main.async {
                guard let strongSelf = self else { return }
                
                if let passport = passport {
                    // Log PA/AA status for debugging
                    print("=== iOS NFC READ SUCCESS ===")
                    print("Raw PA Status: \(passport.passedPA)")
                    print("Raw AA Status: \(passport.passedAA)")
                    print("Converted PA: \(strongSelf.dgResponseToString(passport.passedPA))")
                    print("Converted AA: \(strongSelf.dgResponseToString(passport.passedAA))")
                    print("=============================")
                    
                    // Convert passport to dictionary
                    let passportDict = strongSelf.passportToDictionary(passport)
                    threadSafeResult.send(passportDict)
                    strongSelf.nfcReader = nil
                    strongSelf.currentReadResult = nil
                } else if let progress = progress {
                    // Send progress update as primitive Int (0-100)
                    let progressInt = Int(progress)
                    strongSelf.channel?.invokeMethod("onProgress", arguments: progressInt)
                } else if let error = error {
                    threadSafeResult.send(FlutterError(code: NfcSdkErrorName.code(for: error) ?? "NFC_ERROR", message: error.localizedDescription, details: nil))
                    strongSelf.nfcReader = nil
                    strongSelf.currentReadResult = nil
                }
            }
        }
#else
        result(FlutterError(code: "FRAMEWORK_NOT_AVAILABLE", message: "UdentifyNFC framework or UdentifyCommons dependency not available. Please ensure both frameworks are properly configured.", details: nil))
#endif
    }
    
    private func cancelReading(result: @escaping FlutterResult) {
#if canImport(UdentifyNFC)
        // Explicitly resolve the pending readPassport result with CANCELLED,
        // mirroring Android's guaranteed resolution. We don't rely on the
        // vendor SDK re-invoking the original read closure on cancel.
        // ThreadSafeFlutterResult guards against double-completion, so this
        // stays safe even if the vendor SDK's callback also fires afterward.
        if let pendingReadResult = self.currentReadResult {
            pendingReadResult.send(FlutterError(code: "CANCELLED", message: "Reading was cancelled", details: nil))
            self.currentReadResult = nil
        }

        if let nfcReader = self.nfcReader {
            nfcReader.cancelReading { [weak self] in
                DispatchQueue.main.async {
                    result(nil)
                    self?.nfcReader = nil
                }
            }
        } else {
            result(nil)
        }
#else
        result(FlutterError(code: "FRAMEWORK_NOT_AVAILABLE", message: "UdentifyNFC framework not available", details: nil))
#endif
    }
    
    private func getNfcLocation(call: FlutterMethodCall, result: @escaping FlutterResult) {
#if canImport(UdentifyNFC)
        let threadSafeResult = ThreadSafeFlutterResult(result)
        
        guard let args = call.arguments as? [String: Any],
              let serverURL = args["serverURL"] as? String else {
            threadSafeResult.send(FlutterError(code: "INVALID_ARGUMENTS", message: "Invalid arguments", details: nil))
            return
        }
        
        self.nfcLocator = NFCLocator(serverURL: serverURL)
        
        self.nfcLocator?.locateNFC { [weak self, threadSafeResult] location, error in
            DispatchQueue.main.async {
                guard let strongSelf = self else { return }
                
                if let error = error {
                    threadSafeResult.send(FlutterError(code: "LOCATION_ERROR", message: error.localizedDescription, details: nil))
                } else if let location = location {
                    threadSafeResult.send(strongSelf.nfcLocationToJSON(location))
                } else {
                    threadSafeResult.send(strongSelf.nfcLocationToJSON(nil))
                }
                strongSelf.nfcLocator = nil
            }
        }
#else
        result(FlutterError(code: "FRAMEWORK_NOT_AVAILABLE", message: "UdentifyNFC framework not available", details: nil))
#endif
    }
    
    private func checkPermissions(result: @escaping FlutterResult) {
        // iOS doesn't require runtime permissions for NFC
        // NFC capability is handled at build time
        let permissions = [
            "hasPhoneStatePermission": true, // Not applicable on iOS
            "hasNfcPermission": true // Handled by NFC capability
        ]
        result(permissions)
    }
    
    private func requestPermissions(result: @escaping FlutterResult) {
        // iOS doesn't require runtime permissions for NFC
        result("granted")
    }
    
    // MARK: - Helper Methods
    
#if canImport(UdentifyNFC)
    private func passportToDictionary(_ passport: Passport) -> [String: Any] {
        var dict: [String: Any] = [:]
        
        if let image = passport.image {
            if let imageData = image.jpegData(compressionQuality: 0.8) {
                let base64Image = imageData.base64EncodedString()
                dict["image"] = base64Image
            }
        }
        
        if let firstName = passport.firstName {
            dict["firstName"] = firstName
        }
        
        if let lastName = passport.lastName {
            dict["lastName"] = lastName
        }
        
        // Same keys the Android layer sends.
        if let value = passport.documentNumber { dict["documentNumber"] = value }
        if let value = passport.nationality { dict["nationality"] = value }
        if let value = passport.dateOfBirth { dict["dateOfBirth"] = value }
        if let value = passport.documentExpiryDate { dict["expiryDate"] = value }
        if let value = passport.gender { dict["gender"] = value }
        if let value = passport.documentType { dict["issuer"] = value }
        if let value = passport.personalNumber { dict["personalNumber"] = value }
        dict["placeOfBirth"] = passport.birthPlace
        dict["address"] = passport.address

        dict["passedPA"] = self.dgResponseToString(passport.passedPA)
        dict["passedAA"] = self.dgResponseToString(passport.passedAA)
        dict["passedCA"] = self.dgResponseToString(passport.passedCA)
        dict["phoneNumber"] = passport.phoneNumber
        if let value = passport.documentCode { dict["documentCode"] = value }
        if let value = passport.issuingAuthority { dict["issuingAuthority"] = value }
        if let value = passport.dateOfIssue { dict["dateOfIssue"] = value }
        dict["accessControlProtocol"] = passport.accessControlProtocol.rawValue
        
        return dict
    }
    

    
    private func dgResponseToString(_ response: DGResponse) -> String {
        switch response {
        case .True: return "true"
        case .False: return "false"
        case .Disabled: return "disabled"
        case .NotSupported: return "notSupported"
        @unknown default: return "notSupported"
        }
    }
    
    private func nfcLocationToString(_ location: NFCLocation) -> String {
        switch location {
        case .frontTop: return "frontTop"
        case .frontCenter: return "frontCenter"
        case .frontBottom: return "frontBottom"
        case .rearTop: return "rearTop"
        case .rearCenter: return "rearCenter"
        case .rearBottom: return "rearBottom"
        @unknown default: return "unknown"
        }
    }

    // Builds the same JSON shape Android sends for getNfcLocation
    // ({"success":..., "location":..., "locationString":...}) so Dart's
    // jsonDecode(...) works identically on both platforms. NFCLocation's
    // rawValue (Int) lines up with Android's numeric location codes
    // (unknown=0, frontTop=1, frontCenter=2, frontBottom=3, rearTop=4,
    // rearCenter=5, rearBottom=6).
    private func nfcLocationToJSON(_ location: NFCLocation?) -> String {
        let locationString = location.map { nfcLocationToString($0) } ?? "unknown"
        let locationCode = location?.rawValue ?? 0
        let resultMap: [String: Any] = [
            "success": location != nil,
            "location": locationCode,
            "locationString": locationString,
        ]

        if let jsonData = try? JSONSerialization.data(withJSONObject: resultMap),
           let jsonString = String(data: jsonData, encoding: .utf8) {
            return jsonString
        }
        return "{\"success\":false,\"location\":0,\"locationString\":\"unknown\"}"
    }
#endif
}

// MARK: - NFCReaderSessionDelegate

#if canImport(UdentifyNFC)
extension NfcFlutterPlugin: NFCReaderSessionDelegate {
    public func nfcReaderSessionDidBegin() {
        // Session started - could emit event here if needed
    }
    
    public func nfcReaderSessionDidEnd(with message: String?) {
        // Session ended - could emit event here if needed
    }
}
#endif
