import Flutter
import UIKit
import AVFoundation
import UdentifyCommons
import udentify_core_flutter

// Import UdentifyFACE framework if available
#if canImport(UdentifyFACE)
import UdentifyFACE
#endif

#if canImport(UdentifyFACE)
/// The SDK's own error name for a `FaceError`, in the vocabulary the Android SDK reports (its `ERR_*`
/// string resources), so a failure reads the same on both platforms. Only cases with a clear
/// counterpart are named; every other error returns `nil` and keeps the code it always had.
/// The pairing is by meaning, not taken from an SDK mapping table.
enum FaceSdkErrorName {
    static func code(for error: Error) -> String? {
        guard let faceError = error as? FaceError else { return nil }
        switch faceError {
        case .faceImageMissing: return "ERR_FACE_PHOTO_MISSING"
        case .userIDMissing, .transactionIDMissing, .serverURLMissing: return "ERR_FACE_CREDENTIALS_MISSING"
        case .cameraPermissionRequired: return "ERR_CAMERA_PERMISSION_REQUIRED"
        case .notConsistent: return "ERR_FACEKEY_NOT_CONSISTENT"
        case .notAlive: return "ERR_FACEKEY_NOT_ALIVE"
        case .notMatch: return "ERR_FACEKEY_NO_MATCH"
        case .processTimeout: return "ERR_FACEKEY_TIMEOUT"
        case .photoCaptureError: return "ERR_FAILED_TO_TAKE_SELFIE"
        case .other: return "ERR_UNKNOWN"
        default: return nil
        }
    }
}
#endif

#if canImport(UdentifyFACE)
class LocalizationManager {
  static let shared = LocalizationManager()
  
  private var currentLanguage: String = "en"
  private var customStrings: [String: String] = [:]
  
  private init() {}
  
  func setLanguage(_ languageCode: String) {
    self.currentLanguage = languageCode
  }
  
  func setCustomStrings(_ strings: [String: String]) {
    self.customStrings = strings
  }
  
  func localizedString(for key: String, defaultValue: String = "") -> String {
    // First check custom strings
    if let customValue = customStrings[key] {
      return customValue
    }
    
    // Then check plugin bundle localization
    let pluginBundle = UdentifyLanguagePreference.localizedBundle(for: Bundle(for: LivenessFlutterPlugin.self))
    if let path = pluginBundle.path(forResource: currentLanguage, ofType: "lproj"),
       let bundle = Bundle(path: path) {
      let localizedValue = NSLocalizedString(key, tableName: nil, bundle: bundle, value: defaultValue, comment: "")
      if localizedValue != key {
        return localizedValue
      }
    }
    
    // Fallback to main bundle
    if let path = Bundle.main.path(forResource: currentLanguage, ofType: "lproj"),
       let bundle = Bundle(path: path) {
      let localizedValue = NSLocalizedString(key, tableName: nil, bundle: bundle, value: defaultValue, comment: "")
      if localizedValue != key {
        return localizedValue
      }
    }
    
    // Fallback to English or default value
    return NSLocalizedString(key, value: defaultValue, comment: "")
  }
}

// MARK: - Custom Settings Implementation
struct FlutterApiSettings: ApiSettings {
  var colors: ApiColors
  var fonts: ApiFonts
  var configs: ApiConfigs
  
  /// The wrapper holds no look of its own. Every value the app did not supply comes from the SDK's
  /// default-constructed settings, so the screens keep the vendor's appearance and follow it when
  /// the SDK changes. The one thing decided here is the localization bundle.
  init(from arguments: [String: Any]) {
    // Extract colors configuration
    let colorsDict = arguments["colors"] as? [String: Any] ?? [:]
    let sdkColors = ApiColors()
    self.colors = ApiColors(
      titleColor: UIColor.fromHex(colorsDict["titleColor"] as? String) ?? sdkColors.titleColor,
      titleBG: UIColor.fromHex(colorsDict["titleBG"] as? String) ?? sdkColors.titleBG,
      errorColor: UIColor.fromHex(colorsDict["buttonErrorColor"] as? String) ?? sdkColors.buttonErrorColor,
      successColor: UIColor.fromHex(colorsDict["buttonSuccessColor"] as? String) ?? sdkColors.buttonSuccessColor,
      buttonColor: UIColor.fromHex(colorsDict["buttonColor"] as? String) ?? sdkColors.buttonColor,
      buttonTextColor: UIColor.fromHex(colorsDict["buttonTextColor"] as? String) ?? sdkColors.buttonTextColor,
      buttonErrorTextColor: UIColor.fromHex(colorsDict["buttonErrorTextColor"] as? String) ?? sdkColors.buttonErrorTextColor,
      buttonSuccessTextColor: UIColor.fromHex(colorsDict["buttonSuccessTextColor"] as? String) ?? sdkColors.buttonSuccessTextColor,
      buttonBackColor: UIColor.fromHex(colorsDict["buttonBackColor"] as? String) ?? sdkColors.buttonBackColor,
      footerTextColor: UIColor.fromHex(colorsDict["footerTextColor"] as? String) ?? sdkColors.footerTextColor,
      checkmarkTintColor: UIColor.fromHex(colorsDict["checkmarkTintColor"] as? String) ?? sdkColors.checkmarkTintColor,
      backgroundColor: UIColor.fromHex(colorsDict["backgroundColor"] as? String) ?? sdkColors.backgroundColor
    )
    
    // Extract fonts configuration. ApiFonts exposes no readable properties, so the fallback mirrors
    // the value in the SDK's own initializer (bold system font, 24pt); re-check it when the
    // framework is upgraded.
    let fontsDict = arguments["fonts"] as? [String: Any] ?? [:]
    let sdkFont = UIFont.boldSystemFont(ofSize: 24)
    self.fonts = ApiFonts(
      titleFont: UIFont.fromDict(fontsDict["titleFont"] as? [String: Any]) ?? sdkFont,
      buttonFont: UIFont.fromDict(fontsDict["buttonFont"] as? [String: Any]) ?? sdkFont,
      footerFont: UIFont.fromDict(fontsDict["footerFont"] as? [String: Any]) ?? sdkFont
    )
    
    // Extract dimensions configuration
    let dimensionsDict = arguments["dimensions"] as? [String: Any] ?? [:]
    
    // Extract configs
    let configsDict = arguments["configs"] as? [String: Any] ?? [:]
    let sdk = ApiConfigs()
    
    // The app's progress bar style, when it gave one; otherwise the SDK's own (none).
    let progressBarStyle: UdentifyProgressBarStyle?
    if let progressBarDict = configsDict["progressBarStyle"] as? [String: Any] {
      progressBarStyle = UdentifyProgressBarStyle.fromDict(progressBarDict)
    } else {
      progressBarStyle = sdk.progressBarStyle
    }
    
    self.configs = ApiConfigs(
      cameraPosition: (configsDict["cameraPosition"] as? String).map { (value: String) -> AVCaptureDevice.Position in value == "back" ? .back : .front } ?? sdk.cameraPosition,
      // requestTimeout has no readable property; 30 is the SDK initializer's default.
      requestTimeout: configsDict["requestTimeout"] as? TimeInterval ?? 30,
      autoTake: configsDict["autoTake"] as? Bool ?? sdk.autoTake,
      errorDelay: configsDict["errorDelay"] as? Double ?? sdk.errorDelay,
      successDelay: configsDict["successDelay"] as? Double ?? sdk.successDelay,
      bundle: UdentifyLanguagePreference.localizedBundle(for: Bundle(for: LivenessFlutterPlugin.self)),
      tableName: configsDict["tableName"] as? String ?? sdk.tableName,
      maskDetection: configsDict["maskDetection"] as? Bool ?? sdk.maskDetection,
      maskConfidence: (configsDict["maskConfidence"] as? Double).map { (value: Double) -> Float in Float(value) } ?? sdk.maskConfidence,
      invertedAnimation: configsDict["invertedAnimation"] as? Bool ?? sdk.invertedAnimation,
      backButtonEnabled: configsDict["backButtonEnabled"] as? Bool ?? sdk.backButtonEnabled,
      multipleFacesRejected: configsDict["multipleFacesRejected"] as? Bool ?? sdk.multipleFacesRejected,
      buttonHeight: dimensionsDict["buttonHeight"] as? CGFloat ?? configsDict["buttonHeight"] as? CGFloat ?? sdk.buttonHeight,
      buttonMarginLeft: dimensionsDict["buttonMarginLeft"] as? CGFloat ?? configsDict["buttonMarginLeft"] as? CGFloat ?? sdk.buttonMarginLeft,
      buttonMarginRight: dimensionsDict["buttonMarginRight"] as? CGFloat ?? configsDict["buttonMarginRight"] as? CGFloat ?? sdk.buttonMarginRight,
      buttonCornerRadius: dimensionsDict["buttonCornerRadius"] as? CGFloat ?? configsDict["buttonCornerRadius"] as? CGFloat ?? sdk.buttonCornerRadius,
      progressBarStyle: progressBarStyle
    )
  }
}

// MARK: - UIColor Extension
extension UIColor {
  /// `#RGB`, `#RRGGBB` or `#AARRGGBB` (the convention of every Flutter plugin here). Anything else is
  /// nil, so the caller keeps the SDK's own colour instead of getting a wrong one.
  static func fromHex(_ hex: String?) -> UIColor? {
    guard var value = hex?.trimmingCharacters(in: .whitespacesAndNewlines), value.hasPrefix("#") else { return nil }
    value.removeFirst()
    if value.count == 3 { value = value.map { "\($0)\($0)" }.joined() }
    guard value.count == 6 || value.count == 8, let number = UInt64(value, radix: 16) else { return nil }
    let alpha: CGFloat = value.count == 8 ? CGFloat((number & 0xFF000000) >> 24) / 255.0 : 1.0
    return UIColor(
      red: CGFloat((number & 0x00FF0000) >> 16) / 255.0,
      green: CGFloat((number & 0x0000FF00) >> 8) / 255.0,
      blue: CGFloat(number & 0x000000FF) / 255.0,
      alpha: alpha
    )
  }
}

// MARK: - UIFont Extension
extension UIFont {
  static func fromDict(_ dict: [String: Any]?) -> UIFont? {
    guard let dict = dict,
          let name = dict["name"] as? String,
          let size = dict["size"] as? CGFloat else { return nil }
    
    if let font = UIFont(name: name, size: size) {
      return font
    }
    
    // Fallback to system font
    return UIFont.systemFont(ofSize: size)
  }
}

// MARK: - UdentifyProgressBarStyle Extension
extension UdentifyProgressBarStyle {
  static func fromDict(_ dict: [String: Any]) -> UdentifyProgressBarStyle {
    let textStyleDict = dict["textStyle"] as? [String: Any] ?? [:]
    
    return UdentifyProgressBarStyle(
      backgroundColor: UIColor.fromHex(dict["backgroundColor"] as? String) ?? .lightGray.withAlphaComponent(0.5),
      progressColor: UIColor.fromHex(dict["progressColor"] as? String) ?? .gray,
      completionColor: UIColor.fromHex(dict["completionColor"] as? String) ?? .green,
      textStyle: UdentifyTextStyle.fromDict(textStyleDict),
      cornerRadius: dict["cornerRadius"] as? CGFloat ?? 8
    )
  }
}

// MARK: - UdentifyTextStyle Extension
extension UdentifyTextStyle {
  static func fromDict(_ dict: [String: Any]) -> UdentifyTextStyle {
    let font = UIFont.fromDict(dict["font"] as? [String: Any]) ?? .boldSystemFont(ofSize: 24)
    let textColor = UIColor.fromHex(dict["textColor"] as? String) ?? .white
    
    var textAlignment: NSTextAlignment = .center
    if let alignmentString = dict["textAlignment"] as? String {
      switch alignmentString {
      case "left": textAlignment = .left
      case "right": textAlignment = .right
      case "center": textAlignment = .center
      case "justified": textAlignment = .justified
      case "natural": textAlignment = .natural
      default: textAlignment = .center
      }
    }
    
    var lineBreakMode: NSLineBreakMode = .byWordWrapping
    if let lineBreakString = dict["lineBreakMode"] as? String {
      switch lineBreakString {
      case "byWordWrapping": lineBreakMode = .byWordWrapping
      case "byTruncatingTail": lineBreakMode = .byTruncatingTail
      case "byTruncatingHead": lineBreakMode = .byTruncatingHead
      case "byClipping": lineBreakMode = .byClipping
      default: lineBreakMode = .byWordWrapping
      }
    }
    
    return UdentifyTextStyle(
      font: font,
      textColor: textColor,
      textAlignment: textAlignment,
      lineBreakMode: lineBreakMode,
      numberOfLines: dict["numberOfLines"] as? Int ?? 0,
      leading: dict["leading"] as? CGFloat ?? 20,
      trailing: dict["trailing"] as? CGFloat ?? 20
    )
  }
}
#endif

public class LivenessFlutterPlugin: NSObject, FlutterPlugin {
  private var channel: FlutterMethodChannel?
  private var currentViewController: UIViewController?
  private var currentIDCameraController: IDCameraController? // For API calls with captured images
  private var isInProgress = false
#if canImport(UdentifyFACE)
  // The settings the app last configured, kept so LiveKYC's in-call face screen can be given the
  // same ones. Process-wide, like the SDK's own settings provider: a second Flutter engine (a headless
  // one from a background task, say) creates its own plugin instance and must neither reset these nor
  // take them with it when it is destroyed.
  fileprivate static var lastConfiguredSettings: FlutterApiSettings?
#endif
  
  public override init() {
    super.init()
    setupDefaultSettings()
  }
  
  private func setupDefaultSettings() {
#if canImport(UdentifyFACE)
    // Never over an app's configuration: this runs for every engine's plugin instance.
    guard Self.lastConfiguredSettings == nil else { return }
    let defaultSettings = FlutterApiSettings(from: [:])
    ApiSettingsProvider.getInstance().currentSettings = defaultSettings
#endif
  }
  
  public static func register(with registrar: FlutterPluginRegistrar) {
    let channel = FlutterMethodChannel(name: "liveness_flutter", binaryMessenger: registrar.messenger())
    let instance = LivenessFlutterPlugin()
    instance.channel = channel
    registrar.addMethodCallDelegate(instance, channel: channel)

#if canImport(UdentifyFACE)
    // In-call LiveKYC face capture gets the same settings the standalone flows use: the app's
    // when it configured any, otherwise the plugin's defaults. Read when the closure runs, so a
    // configuration applied later still reaches the next in-call capture.
    UdentifyLiveKYCModuleSettings.installFaceSettings = {
      ApiSettingsProvider.getInstance().currentSettings =
        LivenessFlutterPlugin.lastConfiguredSettings ?? FlutterApiSettings(from: [:])
    }
#endif
  }

  public func handle(_ call: FlutterMethodCall, result: @escaping FlutterResult) {
    let method = call.method
    
    switch method {
    case "checkPermissions":
      checkPermissions(result: result)
    case "requestPermissions":
      requestPermissions(result: result)
    case "startFaceRecognitionRegistration":
      startFaceRecognitionRegistration(call: call, result: result)
    case "startFaceRecognitionAuthentication":
      startFaceRecognitionAuthentication(call: call, result: result)
    case "startActiveLiveness":
      startActiveLiveness(call: call, result: result)
    case "startHybridLiveness":
      startHybridLiveness(call: call, result: result)
    case "registerUserWithPhoto":
      registerUserWithPhoto(call: call, result: result)
    case "authenticateUserWithPhoto":
      authenticateUserWithPhoto(call: call, result: result)
    case "startSelfieCapture":
      startSelfieCapture(call: call, result: result)
    case "performFaceRecognitionWithSelfie":
      performFaceRecognitionWithSelfie(call: call, result: result)
    case "cancelFaceRecognition":
      cancelFaceRecognition(result: result)
    case "isFaceRecognitionInProgress":
      isFaceRecognitionInProgress(result: result)
    case "addUserToList":
      addUserToList(call: call, result: result)
    case "startFaceRecognitionIdentification":
      startFaceRecognitionIdentification(call: call, result: result)
    case "deleteUserFromList":
      deleteUserFromList(call: call, result: result)
    case "configureUISettings":
      configureUISettings(call: call, result: result)
    case "setLocalization":
      setLocalization(call: call, result: result)
    case "estimateDemographics":
      estimateDemographics(call: call, result: result)
    default:
      result(FlutterError(code: "UNIMPLEMENTED",
                         message: "Method not implemented: \(method)",
                         details: nil))
    }
  }

  private func estimateDemographics(call: FlutterMethodCall, result: @escaping FlutterResult) {
    #if canImport(UdentifyFACE)
    guard let args = call.arguments as? [String: Any],
          let serverURL = args["serverURL"] as? String,
          let transactionID = args["transactionID"] as? String,
          let imageBase64 = args["imageBase64"] as? String,
          let imageData = Data(base64Encoded: imageBase64),
          let image = UIImage(data: imageData) else {
      result(FlutterError(code: "INVALID_ARGUMENTS",
                          message: "serverURL, transactionID and a valid base64 imageBase64 are required",
                          details: nil))
      return
    }

    DispatchQueue.main.async {
      IDCameraController.performAgeEstimation(
        serverURL: serverURL,
        transactionID: transactionID,
        image: image
      ) { age, gender in
        DispatchQueue.main.async {
          if age == nil && gender == nil {
            result(FlutterError(code: "DEMOGRAPHICS_ERROR",
                                message: "Demographics estimation failed",
                                details: nil))
          } else {
            var demographics: [String: Any] = [:]
            if let age = age { demographics["estimatedAge"] = age }
            if let gender = gender { demographics["estimatedGender"] = gender }
            result(demographics)
          }
        }
      }
    }
    #else
    result(FlutterError(code: "SDK_NOT_AVAILABLE",
                        message: "UdentifyFACE framework is not available",
                        details: nil))
    #endif
  }
  
  private func checkPermissions(result: @escaping FlutterResult) {
    // Check camera permission status
    let cameraStatus = getCameraPermissionStatus()
    
    let permissions = [
      "camera": cameraStatus,
      "readPhoneState": "granted", // Not applicable on iOS
      "internet": "granted" // Not applicable on iOS
    ]
    
    result(permissions)
  }
  
  private func requestPermissions(result: @escaping FlutterResult) {
    // Request camera permission
    requestCameraPermission { [weak self] in
      self?.checkPermissions(result: result)
    }
  }
  
  private func startFaceRecognitionRegistration(call: FlutterMethodCall, result: @escaping FlutterResult) {
#if canImport(UdentifyFACE) && canImport(UdentifyCommons)
    guard !isInProgress else {
      result(FlutterError(code: "ALREADY_IN_PROGRESS", message: "Face recognition is already in progress", details: nil))
      return
    }
    
    guard let arguments = call.arguments as? [String: Any],
          let serverURL = arguments["serverURL"] as? String,
          let transactionId = arguments["transactionID"] as? String else {
      result(FlutterError(code: "INVALID_ARGUMENTS", message: "Missing required arguments: serverURL, transactionID", details: nil))
      return
    }
    
    let userId = arguments["userID"] as? String
    let logLevel = convertLogLevel(arguments["logLevel"] as? String ?? "warning")
    
    DispatchQueue.main.async { [weak self] in
      guard let self = self else { return }
      
      IDCameraController.instantiate(
        serverURL: serverURL,
        method: .registration,
        transactionID: transactionId,
        userID: userId,
        listName: nil,
        logLevel: logLevel
      ) { [weak self] controller, error in
        if let error = error {
          result(FlutterError(code: "INITIALIZATION_FAILED", message: "Failed to initialize face recognition: \(error.localizedDescription)", details: nil))
          return
        }
        
        guard let controller = controller,
              let presenter = UdentifyPresenter.topViewController() else {
          result(FlutterError(code: "NO_VIEW_CONTROLLER", message: "Could not find a view controller to present from", details: nil))
          return
        }
        
        controller.delegate = self
        self?.currentViewController = controller
        self?.isInProgress = true
        presenter.present(controller, animated: true)
        
        result([
          "status": "success",
          "faceIDMessage": [
            "success": true,
            "message": "Face recognition registration started"
          ]
        ])
      }
    }
#else
    result(FlutterError(code: "FRAMEWORK_NOT_AVAILABLE", message: "UdentifyFACE framework not available. Please add UdentifyFACE.xcframework to ios/Frameworks/", details: nil))
#endif
  }
  
  private func startFaceRecognitionAuthentication(call: FlutterMethodCall, result: @escaping FlutterResult) {
#if canImport(UdentifyFACE) && canImport(UdentifyCommons)
    guard !isInProgress else {
      result(FlutterError(code: "ALREADY_IN_PROGRESS", message: "Face recognition is already in progress", details: nil))
      return
    }
    
    guard let arguments = call.arguments as? [String: Any],
          let serverURL = arguments["serverURL"] as? String,
          let transactionId = arguments["transactionID"] as? String else {
      result(FlutterError(code: "INVALID_ARGUMENTS", message: "Missing required arguments: serverURL, transactionID", details: nil))
      return
    }
    
    let userId = arguments["userID"] as? String
    let logLevel = convertLogLevel(arguments["logLevel"] as? String ?? "warning")
    
    DispatchQueue.main.async { [weak self] in
      guard let self = self else { return }
      
      IDCameraController.instantiate(
        serverURL: serverURL,
        method: .authentication,
        transactionID: transactionId,
        userID: userId,
        listName: nil,
        logLevel: logLevel
      ) { [weak self] controller, error in
        if let error = error {
          result(FlutterError(code: "INITIALIZATION_FAILED", message: "Failed to initialize face recognition: \(error.localizedDescription)", details: nil))
          return
        }
        
        guard let controller = controller,
              let presenter = UdentifyPresenter.topViewController() else {
          result(FlutterError(code: "NO_VIEW_CONTROLLER", message: "Could not find a view controller to present from", details: nil))
          return
        }
        
        controller.delegate = self
        self?.currentViewController = controller
        self?.isInProgress = true
        presenter.present(controller, animated: true)
        
        result([
          "status": "success",
          "faceIDMessage": [
            "success": true,
            "message": "Face recognition authentication started"
          ]
        ])
      }
    }
#else
    result(FlutterError(code: "FRAMEWORK_NOT_AVAILABLE", message: "UdentifyFACE framework not available. Please add UdentifyFACE.xcframework to ios/Frameworks/", details: nil))
#endif
  }
  
  private func startActiveLiveness(call: FlutterMethodCall, result: @escaping FlutterResult) {
#if canImport(UdentifyFACE) && canImport(UdentifyCommons)
    guard !isInProgress else {
      result(FlutterError(code: "ALREADY_IN_PROGRESS", message: "Active liveness is already in progress", details: nil))
      return
    }
    
    guard let arguments = call.arguments as? [String: Any],
          let serverURL = arguments["serverURL"] as? String,
          let transactionId = arguments["transactionID"] as? String,
          let userId = arguments["userID"] as? String else {
      result(FlutterError(code: "INVALID_ARGUMENTS", message: "Missing required arguments: serverURL, transactionID, userID", details: nil))
      return
    }
    
    let isAuthentication = arguments["isAuthentication"] as? Bool ?? false
    let hybridLivenessEnabled = arguments["hybridLivenessEnabled"] as? Bool ?? false
    let autoNextEnabled = (arguments["activeLivenessAutoNextEnabled"] ?? arguments["autoNextEnabled"]) as? Bool ?? true
    let logLevel = convertLogLevel(arguments["logLevel"] as? String ?? "warning")
    
    DispatchQueue.main.async { [weak self] in
      guard let self = self else { return }
      
      // Debug logging for troubleshooting
      print("🔧 ActiveCameraController.instantiate called with:")
      print("   serverURL: '\(serverURL)'")
      print("   transactionID: '\(transactionId)'") 
      print("   userID: '\(userId)'")
      print("   isAuthentication: \(isAuthentication)")
      print("   hybridLivenessEnabled: \(hybridLivenessEnabled)")
      print("   autoNextEnabled: \(autoNextEnabled)")
      print("   logLevel: \(logLevel)")
      
      ActiveCameraController.instantiate(
        serverURL: serverURL,
        method: isAuthentication ? .authentication : .registration,
        transactionID: transactionId,
        userID: userId,
        hybridLivenessEnabled: hybridLivenessEnabled,
        autoNextEnabled: autoNextEnabled,
        logLevel: logLevel
      ) { [weak self] controller, error in
        if let error = error {
          print("❌ ActiveCameraController instantiation failed:")
          print("   Error: \(error)")
          print("   LocalizedDescription: \(error.localizedDescription)")
          print("   Error type: \(type(of: error))")
          result(FlutterError(code: "INITIALIZATION_FAILED", message: "Failed to initialize active liveness: \(error.localizedDescription)", details: ["serverURL": serverURL, "transactionID": transactionId, "userID": userId, "error": "\(error)"]))
          return
        }
        
        guard let controller = controller,
              let presenter = UdentifyPresenter.topViewController() else {
          result(FlutterError(code: "NO_VIEW_CONTROLLER", message: "Could not find a view controller to present from", details: nil))
          return
        }
        
        print("🔧 Setting ActiveCameraController delegate to self")
        controller.delegate = self
        self?.currentViewController = controller
        self?.isInProgress = true
        print("🚀 Presenting ActiveCameraController")
        presenter.present(controller, animated: true)
        
        result([
          "status": "success",
          "faceIDMessage": [
            "success": true,
            "message": "Active liveness started"
          ]
        ])
      }
    }
#else
    result(FlutterError(code: "FRAMEWORK_NOT_AVAILABLE", message: "UdentifyFACE framework not available. Please add UdentifyFACE.xcframework to ios/Frameworks/", details: nil))
#endif
  }
  
  private func startHybridLiveness(call: FlutterMethodCall, result: @escaping FlutterResult) {
#if canImport(UdentifyFACE) && canImport(UdentifyCommons)
    guard !isInProgress else {
      result(FlutterError(code: "ALREADY_IN_PROGRESS", message: "Hybrid liveness is already in progress", details: nil))
      return
    }
    
    guard let arguments = call.arguments as? [String: Any],
          let serverURL = arguments["serverURL"] as? String,
          let transactionId = arguments["transactionID"] as? String,
          let userId = arguments["userID"] as? String else {
      result(FlutterError(code: "INVALID_ARGUMENTS", message: "Missing required arguments: serverURL, transactionID, userID", details: nil))
      return
    }
    
    let isAuthentication = arguments["isAuthentication"] as? Bool ?? false
    let autoNextEnabled = (arguments["activeLivenessAutoNextEnabled"] ?? arguments["autoNextEnabled"]) as? Bool ?? true
    let logLevel = convertLogLevel(arguments["logLevel"] as? String ?? "warning")
    
    DispatchQueue.main.async { [weak self] in
      guard let self = self else { return }
      
      // Debug logging for troubleshooting
      print("🔧 Hybrid Liveness ActiveCameraController.instantiate called with:")
      print("   serverURL: '\(serverURL)'")
      print("   transactionID: '\(transactionId)'") 
      print("   userID: '\(userId)'")
      print("   isAuthentication: \(isAuthentication)")
      print("   autoNextEnabled: \(autoNextEnabled)")
      print("   logLevel: \(logLevel)")
      
      // Use ActiveCameraController with hybrid liveness enabled
      ActiveCameraController.instantiate(
        serverURL: serverURL,
        method: isAuthentication ? .authentication : .registration,
        transactionID: transactionId,
        userID: userId,
        hybridLivenessEnabled: true, // This enables hybrid liveness
        autoNextEnabled: autoNextEnabled,
        logLevel: logLevel
      ) { [weak self] controller, error in
        if let error = error {
          result(FlutterError(code: "INITIALIZATION_FAILED", message: "Failed to initialize hybrid liveness: \(error.localizedDescription)", details: nil))
          return
        }
        
        guard let controller = controller,
              let presenter = UdentifyPresenter.topViewController() else {
          result(FlutterError(code: "NO_VIEW_CONTROLLER", message: "Could not find a view controller to present from", details: nil))
          return
        }
        
        controller.delegate = self
        self?.currentViewController = controller
        self?.isInProgress = true
        presenter.present(controller, animated: true)
        
        result([
          "status": "success",
          "faceIDMessage": [
            "success": true,
            "message": "Hybrid liveness started"
          ]
        ])
      }
    }
#else
    result(FlutterError(code: "FRAMEWORK_NOT_AVAILABLE", message: "UdentifyFACE framework not available. Please add UdentifyFACE.xcframework to ios/Frameworks/", details: nil))
#endif
  }
  
  private func registerUserWithPhoto(call: FlutterMethodCall, result: @escaping FlutterResult) {
#if canImport(UdentifyFACE) && canImport(UdentifyCommons)
    guard let arguments = call.arguments as? [String: Any],
          let serverURL = arguments["serverURL"] as? String,
          let transactionId = arguments["transactionID"] as? String,
          let photoBase64 = arguments["base64Image"] as? String,
          let photoData = Data(base64Encoded: photoBase64),
          let photo = UIImage(data: photoData) else {
      result(FlutterError(code: "INVALID_ARGUMENTS", message: "Missing required arguments: serverURL, transactionID, base64Image", details: nil))
      return
    }

    let userId = arguments["userID"] as? String
    let logLevel = convertLogLevel(arguments["logLevel"] as? String ?? "warning")

    DispatchQueue.main.async { [weak self] in
      IDCameraController.instantiate(
        serverURL: serverURL,
        method: .registration,
        transactionID: transactionId,
        userID: userId,
        listName: nil,
        logLevel: logLevel
      ) { controller, error in
        if let error = error {
          result(FlutterError(code: "INITIALIZATION_FAILED", message: "Failed to initialize face recognition: \(error.localizedDescription)", details: nil))
          return
        }

        guard let controller = controller else {
          result(FlutterError(code: "CONTROLLER_CREATION_FAILED", message: "Could not create camera controller", details: nil))
          return
        }

        // Use the photo-based registration method
        controller.register(forImage: photo) { [weak self] response in
          DispatchQueue.main.async {
            guard let self = self else { return }
            result(self.createPhotoBasedResultMap(faceIDResult: response, failureMessage: "Face registration failed", successMessage: "Face registration completed"))
          }
        }
      }
    }
#else
    result(FlutterError(code: "FRAMEWORK_NOT_AVAILABLE", message: "UdentifyFACE framework not available. Please add UdentifyFACE.xcframework to ios/Frameworks/", details: nil))
#endif
  }
  
  private func authenticateUserWithPhoto(call: FlutterMethodCall, result: @escaping FlutterResult) {
#if canImport(UdentifyFACE) && canImport(UdentifyCommons)
    guard let arguments = call.arguments as? [String: Any],
          let serverURL = arguments["serverURL"] as? String,
          let transactionId = arguments["transactionID"] as? String,
          let photoBase64 = arguments["base64Image"] as? String,
          let photoData = Data(base64Encoded: photoBase64),
          let photo = UIImage(data: photoData) else {
      result(FlutterError(code: "INVALID_ARGUMENTS", message: "Missing required arguments: serverURL, transactionID, base64Image", details: nil))
      return
    }

    let userId = arguments["userID"] as? String
    let logLevel = convertLogLevel(arguments["logLevel"] as? String ?? "warning")

    DispatchQueue.main.async { [weak self] in
      IDCameraController.instantiate(
        serverURL: serverURL,
        method: .authentication,
        transactionID: transactionId,
        userID: userId,
        listName: nil,
        logLevel: logLevel
      ) { controller, error in
        if let error = error {
          result(FlutterError(code: "INITIALIZATION_FAILED", message: "Failed to initialize face recognition: \(error.localizedDescription)", details: nil))
          return
        }

        guard let controller = controller else {
          result(FlutterError(code: "CONTROLLER_CREATION_FAILED", message: "Could not create camera controller", details: nil))
          return
        }

        // Use the photo-based authentication method
        controller.authenticate(forImage: photo) { [weak self] response in
          DispatchQueue.main.async {
            guard let self = self else { return }
            result(self.createPhotoBasedResultMap(faceIDResult: response, failureMessage: "Face authentication failed", successMessage: "Face authentication completed"))
          }
        }
      }
    }
#else
    result(FlutterError(code: "FRAMEWORK_NOT_AVAILABLE", message: "UdentifyFACE framework not available. Please add UdentifyFACE.xcframework to ios/Frameworks/", details: nil))
#endif
  }

  
  private func startSelfieCapture(call: FlutterMethodCall, result: @escaping FlutterResult) {
#if canImport(UdentifyFACE) && canImport(UdentifyCommons)
    NSLog("LivenessFlutterPlugin - 🔄 Starting selfie capture")
    
    guard !isInProgress else {
      result(FlutterError(code: "OPERATION_IN_PROGRESS", message: "Face recognition operation already in progress", details: nil))
      return
    }
    
    guard let arguments = call.arguments as? [String: Any],
          let serverURL = arguments["serverURL"] as? String,
          let transactionID = arguments["transactionID"] as? String,
          let userID = arguments["userID"] as? String else {
      result(FlutterError(code: "INVALID_ARGUMENTS", message: "Missing required arguments: serverURL, transactionID, userID", details: nil))
      return
    }
    
    DispatchQueue.main.async { [weak self] in
      self?.isInProgress = true
      
      // Create IDCameraController for selfie capture using .selfie method
      IDCameraController.instantiate(
        serverURL: serverURL,
        method: .selfie,
        transactionID: transactionID,
        userID: userID,
        listName: nil,
        logLevel: .warning
      ) { controller, error in
        if let error = error {
          self?.isInProgress = false
          result(FlutterError(code: "INITIALIZATION_FAILED", message: "Failed to initialize selfie capture: \(error.localizedDescription)", details: nil))
          return
        }
        
        guard let controller = controller else {
          self?.isInProgress = false
          result(FlutterError(code: "CONTROLLER_CREATION_FAILED", message: "Could not create camera controller for selfie capture", details: nil))
          return
        }
        
        guard let presenter = UdentifyPresenter.topViewController() else {
          self?.isInProgress = false
          result(FlutterError(code: "NO_VIEW_CONTROLLER", message: "Could not find a view controller to present from", details: nil))
          return
        }
        
        controller.delegate = self
        self?.currentViewController = controller
        presenter.present(controller, animated: true)
        
        let resultMap: [String: Any] = [
          "status": "success",
          "faceIDMessage": [
            "success": true,
            "message": "Selfie capture started"
          ]
        ]
        result(resultMap)
      }
    }
#else
    result(FlutterError(code: "FRAMEWORK_NOT_AVAILABLE", message: "UdentifyFACE framework not available. Please add UdentifyFACE.xcframework to ios/Frameworks/", details: nil))
#endif
  }

  private func performFaceRecognitionWithSelfie(call: FlutterMethodCall, result: @escaping FlutterResult) {
#if canImport(UdentifyFACE) && canImport(UdentifyCommons)
    NSLog("LivenessFlutterPlugin - 🔄 Performing face recognition with selfie")
    
    guard let arguments = call.arguments as? [String: Any],
          let serverURL = arguments["serverURL"] as? String,
          let transactionID = arguments["transactionID"] as? String,
          let userID = arguments["userID"] as? String,
          let base64Image = arguments["base64Image"] as? String,
          let isAuthentication = arguments["isAuthentication"] as? Bool else {
      result(FlutterError(code: "INVALID_ARGUMENTS", message: "Missing required arguments: serverURL, transactionID, userID, base64Image, isAuthentication", details: nil))
      return
    }
    
    // Convert base64 image to UIImage
    guard let imageData = Data(base64Encoded: base64Image),
          let image = UIImage(data: imageData) else {
      result(FlutterError(code: "INVALID_IMAGE", message: "Failed to decode base64 image", details: nil))
      return
    }
    
    NSLog("LivenessFlutterPlugin - ✅ Processing selfie with Face Recognition API (isAuth: \(isAuthentication))")
    
    DispatchQueue.main.async { [weak self] in
      NSLog("LivenessFlutterPlugin - ✅ Processing selfie with Face Recognition API")
      
      let logLevel = UdentifyCommons.LogLevel.warning
      let method: MethodType = isAuthentication ? .authentication : .registration
      
      IDCameraController.instantiate(
        serverURL: serverURL,
        method: method,
        transactionID: transactionID,
        userID: userID,
        listName: nil,
        logLevel: logLevel
      ) { [weak self] controller, error in
        guard let self = self else { 
          result(FlutterError(code: "WEAK_SELF", message: "LivenessFlutterPlugin was deallocated", details: nil))
          return 
        }
        
        if let error = error {
          NSLog("LivenessFlutterPlugin - ❌ Failed to initialize controller: \(error.localizedDescription)")
          result(FlutterError(code: "INITIALIZATION_FAILED", message: "Failed to initialize face recognition: \(error.localizedDescription)", details: nil))
          return
        }
        
        guard let controller = controller else {
          NSLog("LivenessFlutterPlugin - ❌ Controller is nil")
          result(FlutterError(code: "NO_CONTROLLER", message: "Could not create face recognition controller", details: nil))
          return
        }
        
        NSLog("LivenessFlutterPlugin - 🎯 Controller created successfully, calling performFaceIDandLiveness")
        
        self.currentIDCameraController = controller
        
        controller.performFaceIDandLiveness(image: image, methodType: method) { faceIDResult, livenessResult in
          DispatchQueue.main.async {
            NSLog("LivenessFlutterPlugin - 📋 performFaceIDandLiveness completed")
            NSLog("LivenessFlutterPlugin - 📊 FaceIDResult: \(faceIDResult?.description ?? "nil")")
            NSLog("LivenessFlutterPlugin - 📊 LivenessResult: \(livenessResult?.assessmentValue ?? 0.0)")
            
            self.currentIDCameraController = nil
            
            if faceIDResult == nil && livenessResult == nil {
              NSLog("LivenessFlutterPlugin - ❌ Both results are nil - this indicates an API call failure")
              result(FlutterError(code: "API_CALL_FAILED", message: "Both faceIDResult and livenessResult are nil", details: nil))
              return
            }
            
            self.currentIDCameraController = nil
            
            let isFailed = self.idCameraFlowFailed(faceIDResult: faceIDResult, livenessResult: livenessResult)
            
            let faceIDMessageDict = self.createFaceIDMessage(faceIDResult: faceIDResult, livenessResult: livenessResult)
            
            let responseResult: [String: Any] = [
              "status": isFailed ? "failure" : "success",
              "faceIDMessage": faceIDMessageDict
            ]
            
            // The event carries the flat payload the camera flows send (with `isFailed` and the typed result keys
            // at the top level), which is what Dart's onResult handler reads; the Future carries the nested form.
            self.channel?.invokeMethod(
              "onResult",
              arguments: self.createRawFaceRecognitionResponse(faceIDResult: faceIDResult, livenessResult: livenessResult))
            result(responseResult)
          }
        }
      }
    }
#else
    result(FlutterError(code: "FRAMEWORK_NOT_AVAILABLE", message: "UdentifyFACE framework not available. Please add UdentifyFACE.xcframework to ios/Frameworks/", details: nil))
#endif
  }
  
  private func addUserToList(call: FlutterMethodCall, result: @escaping FlutterResult) {
#if canImport(UdentifyFACE) && canImport(UdentifyCommons)
    guard let arguments = call.arguments as? [String: Any],
          let serverURL = arguments["serverURL"] as? String,
          // Dart sends `transactionId` and `status` (Android's key names); `transactionID` and
          // `listName` are accepted too. `status` is the list the user is added to.
          let transactionId = (arguments["transactionId"] ?? arguments["transactionID"]) as? String,
          let listName = (arguments["status"] ?? arguments["listName"]) as? String else {
      result(FlutterError(code: "INVALID_ARGUMENTS", message: "Missing required arguments: serverURL, transactionId, status", details: nil))
      return
    }
    
    // Extract metadata if provided
    let metadata = arguments["metadata"] as? [String: Any]
    
    DispatchQueue.main.async {
      IDCameraController.addUserToList(
        serverUrl: serverURL,
        transactionId: transactionId,
        listName: listName,
        metadata: metadata
      ) { response, error in
        DispatchQueue.main.async {
          if let error = error {
            result([
              "success": false,
              "error": [
                "code": "ERR_ADD_USER_TO_LIST",
                "message": error.localizedDescription
              ]
            ])
            return
          }

          guard let response = response else {
            result([
              "success": false,
              "error": [
                "code": "ERR_ADD_USER_TO_LIST",
                "message": "No response from server"
              ]
            ])
            return
          }

          // ListResponseData's properties aren't exposed as public getters in the
          // UdentifyFACE module, but it does conform to Codable, so round-trip it
          // through JSON to recover its real field values instead of fabricating them.
          var data: [String: Any] = [:]
          if let jsonData = try? JSONEncoder().encode(response),
             let jsonObject = try? JSONSerialization.jsonObject(with: jsonData) as? [String: Any] {
            data = jsonObject
          }

          result([
            "success": true,
            "data": data
          ])
        }
      }
    }
#else
    result(FlutterError(code: "FRAMEWORK_NOT_AVAILABLE", message: "UdentifyFACE framework not available. Please add UdentifyFACE.xcframework to ios/Frameworks/", details: nil))
#endif
  }
  
  private func startFaceRecognitionIdentification(call: FlutterMethodCall, result: @escaping FlutterResult) {
#if canImport(UdentifyFACE) && canImport(UdentifyCommons)
    guard !isInProgress else {
      result(FlutterError(code: "ALREADY_IN_PROGRESS", message: "Face recognition is already in progress", details: nil))
      return
    }
    
    guard let arguments = call.arguments as? [String: Any],
          let serverURL = arguments["serverURL"] as? String,
          let transactionId = arguments["transactionID"] as? String,
          let listName = arguments["listName"] as? String else {
      result(FlutterError(code: "INVALID_ARGUMENTS", message: "Missing required arguments: serverURL, transactionID, listName", details: nil))
      return
    }
    
    let logLevel = convertLogLevel(arguments["logLevel"] as? String ?? "warning")
    
    DispatchQueue.main.async { [weak self] in
      guard let self = self else { return }
      
      IDCameraController.instantiate(
        serverURL: serverURL,
        method: .identification,
        transactionID: transactionId,
        userID: nil,
        listName: listName,
        logLevel: logLevel
      ) { [weak self] controller, error in
        if let error = error {
          result(FlutterError(code: "INITIALIZATION_FAILED", message: "Failed to initialize identification: \(error.localizedDescription)", details: nil))
          return
        }
        
        guard let controller = controller,
              let presenter = UdentifyPresenter.topViewController() else {
          result(FlutterError(code: "NO_VIEW_CONTROLLER", message: "Could not find a view controller to present from", details: nil))
          return
        }
        
        controller.delegate = self
        self?.currentViewController = controller
        self?.isInProgress = true
        presenter.present(controller, animated: true)
        
        result([
          "status": "success",
          "faceIDMessage": [
            "success": true,
            "message": "Face identification started"
          ]
        ])
      }
    }
#else
    result(FlutterError(code: "FRAMEWORK_NOT_AVAILABLE", message: "UdentifyFACE framework not available. Please add UdentifyFACE.xcframework to ios/Frameworks/", details: nil))
#endif
  }
  
  private func deleteUserFromList(call: FlutterMethodCall, result: @escaping FlutterResult) {
#if canImport(UdentifyFACE) && canImport(UdentifyCommons)
    guard let arguments = call.arguments as? [String: Any],
          let serverURL = arguments["serverURL"] as? String,
          let transactionId = arguments["transactionID"] as? String,
          let listName = arguments["listName"] as? String,
          let photoBase64 = arguments["photo"] as? String,
          let photoData = Data(base64Encoded: photoBase64),
          let photo = UIImage(data: photoData) else {
      result(FlutterError(code: "INVALID_ARGUMENTS", message: "Missing required arguments: serverURL, transactionID, listName, photo", details: nil))
      return
    }

    DispatchQueue.main.async {
      IDCameraController.deleteUserFromList(
        serverUrl: serverURL,
        transactionId: transactionId,
        listName: listName,
        photo: photo
      ) { listUser, error in
        DispatchQueue.main.async {
          if let error = error {
            result([
              "success": false,
              "error": [
                "code": "ERR_DELETE_USER_FROM_LIST",
                "message": error.localizedDescription
              ]
            ])
            return
          }

          // NOTE: UdentifyFACE's ListUser type exposes no public properties (and isn't
          // Codable) in this SDK version, so userID/matchScore/registrationTransactionID
          // can't be read back from the response on iOS. We echo the request's own
          // transactionID/listName (genuine, not fabricated) and report success based on
          // whether the SDK returned a user with no error.
          result([
            "success": listUser != nil,
            "message": "User deleted from list",
            "data": [
              "transactionID": transactionId,
              "listName": listName
            ]
          ])
        }
      }
    }
#else
    result(FlutterError(code: "FRAMEWORK_NOT_AVAILABLE", message: "UdentifyFACE framework not available. Please add UdentifyFACE.xcframework to ios/Frameworks/", details: nil))
#endif
  }
  
  private func configureUISettings(call: FlutterMethodCall, result: @escaping FlutterResult) {
#if canImport(UdentifyFACE) && canImport(UdentifyCommons)
    guard let arguments = call.arguments as? [String: Any] else {
      result(FlutterError(code: "INVALID_ARGUMENTS", message: "Missing UI settings arguments", details: nil))
      return
    }
    
    DispatchQueue.main.async {
      let customSettings = FlutterApiSettings(from: arguments)
      LivenessFlutterPlugin.lastConfiguredSettings = customSettings
      ApiSettingsProvider.getInstance().currentSettings = customSettings
      result(["status": "success", "message": "UI settings configured"])
    }
#else
    result(FlutterError(code: "FRAMEWORK_NOT_AVAILABLE", message: "UdentifyFACE framework not available. Please add UdentifyFACE.xcframework to ios/Frameworks/", details: nil))
#endif
  }
  
  private func setLocalization(call: FlutterMethodCall, result: @escaping FlutterResult) {
#if canImport(UdentifyFACE) && canImport(UdentifyCommons)
    guard let arguments = call.arguments as? [String: Any],
          let languageCode = arguments["languageCode"] as? String else {
      result(FlutterError(code: "INVALID_ARGUMENTS", message: "Missing language code", details: nil))
      return
    }
    
    // Get custom strings if provided
    let customStrings = arguments["strings"] as? [String: String] ?? [:]
    
    DispatchQueue.main.async {
      // Apply localization settings
      LocalizationManager.shared.setLanguage(languageCode)
      LocalizationManager.shared.setCustomStrings(customStrings)
      
      result(["status": "success", "message": "Localization configured for language: \(languageCode)"])
    }
#else
    result(FlutterError(code: "FRAMEWORK_NOT_AVAILABLE", message: "UdentifyFACE framework not available. Please add UdentifyFACE.xcframework to ios/Frameworks/", details: nil))
#endif
  }
  
  private func cancelFaceRecognition(result: @escaping FlutterResult) {
    if isInProgress {
      isInProgress = false
      currentViewController?.dismiss(animated: true) {
        self.currentViewController = nil
      }
    }
    result(nil)
  }
  
  private func isFaceRecognitionInProgress(result: @escaping FlutterResult) {
    result(isInProgress)
  }
  
  // MARK: - Helper Methods
  
#if canImport(UdentifyFACE) && canImport(UdentifyCommons)
  private func convertLogLevel(_ levelString: String) -> UdentifyCommons.LogLevel {
    switch levelString.lowercased() {
    case "verbose":
      return .verbose
    case "debug":
      return .debug
    case "info":
      return .info
    case "warning":
      return .warning
    case "error":
      return .error
    default:
      return .warning
    }
  }
  
  private func convertUdentifyAnyToSwift(_ udentifyAny: UdentifyCommons.UdentifyAny) -> Any {
    if let stringValue = udentifyAny as? String {
      return stringValue
    } else if let intValue = udentifyAny as? Int {
      return intValue
    } else if let doubleValue = udentifyAny as? Double {
      return doubleValue
    } else if let boolValue = udentifyAny as? Bool {
      return boolValue
    } else if let arrayValue = udentifyAny as? [Any] {
      return arrayValue.map { item in
        if let udentifyAnyItem = item as? UdentifyCommons.UdentifyAny {
          return convertUdentifyAnyToSwift(udentifyAnyItem)
        }
        return item
      }
    } else if let dictValue = udentifyAny as? [String: Any] {
      var convertedDict: [String: Any] = [:]
      for (key, value) in dictValue {
        if let udentifyAnyValue = value as? UdentifyCommons.UdentifyAny {
          convertedDict[key] = convertUdentifyAnyToSwift(udentifyAnyValue)
        } else {
          convertedDict[key] = value
        }
      }
      return convertedDict
    } else {
      return String(describing: udentifyAny)
    }
  }
  
  private func methodTypeToString(_ methodType: MethodType?) -> String {
    guard let methodType = methodType else { return "" }
    switch methodType {
    case .registration:
      return "registration"
    case .authentication:
      return "authentication"
    case .imageUpload:
      return "imageUpload"
    case .selfie:
      return "selfie"
    case .identification:
      return "identification"
    @unknown default:
      return "unknown"
    }
  }
#endif
  
  // MARK: - Helper Methods for Raw Server Response (like Android)
  
  private func createRawServerResponse(faceIDResult: FaceIDResult?, livenessResult: LivenessResult?) -> [String: Any] {
    var rawData: [String: Any] = [:]
    
    // Extract all fields from FaceIDResult using reflection (like Android)
    if let faceIDResult = faceIDResult {
      extractAllFields(from: faceIDResult, into: &rawData)
    }
    
    // Extract all fields from LivenessResult using reflection (like Android)
    if let livenessResult = livenessResult {
      extractAllFields(from: livenessResult, into: &rawData)
    }
    
    rawData["isFailed"] = idCameraFlowFailed(faceIDResult: faceIDResult, livenessResult: livenessResult)
    
    return rawData
  }
  
  /// The ID-camera flow hands back a `FaceIDResult` and a `LivenessResult` separately, so there is no
  /// `FaceIDMessage.isFailed` to read. This is the one rule for both the Future's result and the `onResult`
  /// event: a missing or errored result, an unverified face, or no liveness assessment is a failure.
  private func idCameraFlowFailed(faceIDResult: FaceIDResult?, livenessResult: LivenessResult?) -> Bool {
    if faceIDResult == nil || faceIDResult?.error != nil || faceIDResult?.verified == false { return true }
    return livenessResult == nil || livenessResult?.error != nil || livenessResult?.assessmentValue == nil
  }

  private func createRawActiveLivenessResponse(result: FaceIDMessage) -> [String: Any] {
    var rawData: [String: Any] = [:]
    
    // Extract all fields from FaceIDResult using reflection (like Android)
    if let faceIDResult = result.faceIDResult {
      extractAllFields(from: faceIDResult, into: &rawData)
    }
    
    // Extract all fields from LivenessResult using reflection (like Android)
    if let livenessResult = result.livenessResult {
      extractAllFields(from: livenessResult, into: &rawData)
    }
    
    // Extract all fields from ActiveLivenessResult using reflection (like Android)
    if let activeLivenessResult = result.activeLivenessResult {
      extractAllFields(from: activeLivenessResult, into: &rawData)
    }
    
    // Determine failure status based on actual data
    rawData["isFailed"] = result.isFailed
    
    return rawData
  }
  
  private func createRawFaceRecognitionResponse(faceIDResult: FaceIDResult?, livenessResult: LivenessResult?) -> [String: Any] {
    return createRawServerResponse(faceIDResult: faceIDResult, livenessResult: livenessResult)
  }
  
  // MARK: - Universal Field Extraction (like Android reflection)
  
  private func extractAllFields(from object: Any, into rawData: inout [String: Any]) {
    let mirror = Mirror(reflecting: object)
    
    print("🔍 Extracting all fields from \(type(of: object))")
    
    for child in mirror.children {
      guard let propertyName = child.label else { continue }
      let value = child.value
      
      print("📊 Found property: \(propertyName) = \(value)")
      
      // Handle different value types
      switch value {
      case let stringValue as String:
        rawData[propertyName] = stringValue
      case let numberValue as NSNumber:
        rawData[propertyName] = numberValue
      case let boolValue as Bool:
        rawData[propertyName] = boolValue
      case let doubleValue as Double:
        rawData[propertyName] = doubleValue
      case let floatValue as Float:
        rawData[propertyName] = floatValue
      case let intValue as Int:
        rawData[propertyName] = intValue
      case let imageValue as UIImage:
        // Convert UIImage to base64
        if let imageData = imageValue.jpegData(compressionQuality: 0.8) {
          rawData[propertyName] = imageData.base64EncodedString()
          rawData["\(propertyName)Base64"] = imageData.base64EncodedString()
        }
      case let errorValue as Error:
        rawData[propertyName] = errorValue.localizedDescription
        rawData["\(propertyName)Message"] = errorValue.localizedDescription
      case let dictValue as [String: Any]:
        // Handle dictionary values (like gestureResult)
        rawData[propertyName] = dictValue
        // Also add individual keys from dictionary
        for (key, dictVal) in dictValue {
          rawData[key] = dictVal
        }
      case let metadataValue as [String: UdentifyCommons.UdentifyAny?]:
        // Handle metadata (raw server response data)
        for (key, udentifyAny) in metadataValue {
          if let udentifyAny = udentifyAny {
            rawData[key] = convertUdentifyAnyToSwift(udentifyAny)
          }
        }
        rawData[propertyName] = metadataValue.compactMapValues { udentifyAny in
          udentifyAny != nil ? convertUdentifyAnyToSwift(udentifyAny!) : nil
        }
      case is NSNull:
        rawData[propertyName] = nil
      case Optional<Any>.none:
        rawData[propertyName] = nil
      default:
        // For any other type, convert to string
        rawData[propertyName] = String(describing: value)
      }
    }
    
    print("✅ Extracted \(mirror.children.count) fields from \(type(of: object))")
  }
  
  // MARK: - Helper Methods for Selfie Processing (Legacy - kept for compatibility)
  
  // MARK: - Helper Methods for Photo-Based Register/Authenticate

  // Builds the same {"status", "faceIDMessage"} shape the camera-based flows use so
  // Dart's FaceRecognitionResult.fromMap / FaceIDMessage.fromMap can parse the real
  // verified/matchScore/transactionID data returned by controller.register(forImage:)
  // and controller.authenticate(forImage:) instead of the ad-hoc "result"/"status" map
  // this used to return.
  private func createPhotoBasedResultMap(faceIDResult: FaceIDResult, failureMessage: String, successMessage: String) -> [String: Any] {
    let isFailed = faceIDResult.error != nil || !faceIDResult.verified

    var faceIDResultDict: [String: Any] = [
      "verified": faceIDResult.verified,
      "matchScore": faceIDResult.matchScore,
      "description": faceIDResult.description,
      "transactionID": faceIDResult.transactionID ?? "",
      "userID": faceIDResult.userID ?? "",
      "header": faceIDResult.header ?? "",
      "listNames": faceIDResult.listNames ?? "",
      "listIds": faceIDResult.listIds ?? "",
      "registrationTransactionID": faceIDResult.registrationTransactionID ?? "",
      "method": methodTypeToString(faceIDResult.method)
    ]

    if let error = faceIDResult.error {
      faceIDResultDict["error"] = [
        "code": FaceSdkErrorName.code(for: error) ?? "\(error)",
        "message": error.localizedDescription
      ]
    }

    if let referencePhoto = faceIDResult.referencePhoto,
       let photoData = referencePhoto.jpegData(compressionQuality: 0.8) {
      faceIDResultDict["referencePhotoBase64"] = photoData.base64EncodedString()
    }

    if let metadata = faceIDResult.metadata {
      var metadataDict: [String: Any] = [:]
      for (key, value) in metadata {
        if let udentifyAny = value {
          metadataDict[key] = convertUdentifyAnyToSwift(udentifyAny)
        }
      }
      faceIDResultDict["metadata"] = metadataDict
    }

    let faceIDMessage: [String: Any] = [
      "success": !isFailed,
      "isFailed": isFailed,
      "message": isFailed ? failureMessage : successMessage,
      "faceIDResult": faceIDResultDict
    ]

    return [
      "status": isFailed ? "failure" : "success",
      "faceIDMessage": faceIDMessage
    ]
  }

  private func createFaceIDMessage(faceIDResult: FaceIDResult?, livenessResult: LivenessResult?) -> [String: Any] {
    var faceIDMessage: [String: Any] = [:]
    
    var isFailed = false
    
    // Process FaceIDResult
    if let faceIDResult = faceIDResult {
      var faceIDResultDict: [String: Any] = [
        "verified": faceIDResult.verified,
        "matchScore": faceIDResult.matchScore,
        "description": faceIDResult.description,
        "transactionID": faceIDResult.transactionID ?? "",
        "userID": faceIDResult.userID ?? "",
        "header": faceIDResult.header ?? "",
        "listNames": faceIDResult.listNames ?? "",
        "listIds": faceIDResult.listIds ?? "",
        "registrationTransactionID": faceIDResult.registrationTransactionID ?? "",
        "method": self.methodTypeToString(faceIDResult.method)
      ]
      
      if let error = faceIDResult.error {
        faceIDResultDict["error"] = [
          "code": FaceSdkErrorName.code(for: error) ?? "\(error)",
          "message": error.localizedDescription
        ]
        isFailed = true
      }
      
      if let referencePhoto = faceIDResult.referencePhoto {
        if let imageData = referencePhoto.jpegData(compressionQuality: 0.8) {
          faceIDResultDict["referencePhotoBase64"] = imageData.base64EncodedString()
        }
      }
      
      if let metadata = faceIDResult.metadata {
        var metadataDict: [String: Any] = [:]
        for (key, value) in metadata {
          if let udentifyAny = value {
            metadataDict[key] = convertUdentifyAnyToSwift(udentifyAny)
          }
        }
        faceIDResultDict["metadata"] = metadataDict
      }
      
      faceIDMessage["faceIDResult"] = faceIDResultDict
      
      if faceIDResult.error != nil || !faceIDResult.verified {
        isFailed = true
      }
    } else {
      isFailed = true
    }
    
    // Process LivenessResult
    if let livenessResult = livenessResult {
      var livenessResultDict: [String: Any] = [
        "assessmentValue": livenessResult.assessmentValue ?? 0.0,
        "assessmentDescription": livenessResult.assessmentDescription ?? "",
        "probability": livenessResult.probability ?? 0.0,
        "quality": livenessResult.quality ?? 0.0,
        "livenessScore": livenessResult.livenessScore ?? 0.0,
        "transactionID": livenessResult.transactionID ?? ""
      ]
      
      if let error = livenessResult.error {
        livenessResultDict["error"] = [
          "code": FaceSdkErrorName.code(for: error) ?? "\(error)",
          "message": error.localizedDescription
        ]
        isFailed = true
      }
      
      let assessment = livenessResult.assessment()
      livenessResultDict["assessment"] = assessment.description
      
      faceIDMessage["livenessResult"] = livenessResultDict
      
      if livenessResult.error != nil || livenessResult.assessmentValue == nil {
        isFailed = true
      }
    } else {
      isFailed = true
    }
    
    faceIDMessage["success"] = !isFailed
    faceIDMessage["isFailed"] = isFailed
    faceIDMessage["message"] = isFailed ? "Face recognition failed" : "Face recognition completed"
    
    return faceIDMessage
  }
  
  // MARK: - Camera Permission Methods
  
  private func getCameraPermissionStatus() -> String {
    let status = AVCaptureDevice.authorizationStatus(for: .video)
    
    switch status {
    case .authorized:
      return "granted"
    case .denied:
      return "denied"
    case .restricted:
      return "restricted"
    case .notDetermined:
      return "notDetermined"
    @unknown default:
      return "unknown"
    }
  }
  
  private func requestCameraPermission(completion: @escaping () -> Void) {
    AVCaptureDevice.requestAccess(for: .video) { _ in
      DispatchQueue.main.async {
        completion()
      }
    }
  }
}

#if canImport(UdentifyFACE) && canImport(UdentifyCommons)
extension LivenessFlutterPlugin: IDCameraControllerDelegate {
  public func cameraController(image: UIImage) {
    DispatchQueue.main.async { [weak self] in
      guard let self = self else { return }
      
      NSLog("LivenessFlutterPlugin - 📸 cameraController called with image")
      NSLog("LivenessFlutterPlugin - 🖼️ Image size: \(image.size)")
      
      self.isInProgress = false
      self.currentViewController?.dismiss(animated: true) {
        self.currentViewController = nil
      }
      
      let base64Image = image.jpegData(compressionQuality: 0.8)?.base64EncodedString() ?? ""
      NSLog("LivenessFlutterPlugin - 📷 Base64 image length: \(base64Image.count)")

      // Mirrors Android's FaceRecognizer.onPhotoTaken, fired alongside onSelfieTaken so
      // Dart's setOnPhotoTakenCallback fires the same way on both platforms.
      self.channel?.invokeMethod("onPhotoTaken", arguments: nil)

      let eventBody: [String: Any] = ["base64Image": base64Image]
      self.channel?.invokeMethod("onSelfieTaken", arguments: eventBody)

      NSLog("LivenessFlutterPlugin - ✅ onSelfieTaken event sent")
    }
  }
  
  public func cameraController(didEncounterError error: FaceError) {
    DispatchQueue.main.async { [weak self] in
      guard let self = self else { return }
      
      self.isInProgress = false
      self.currentViewController?.dismiss(animated: true) {
        self.currentViewController = nil
      }
      
      let errorMap: [String: Any] = [
        "code": FaceSdkErrorName.code(for: error) ?? "FACE_RECOGNITION_ERROR",
        "message": error.localizedDescription
      ]
      
      self.channel?.invokeMethod("onFailure", arguments: errorMap)
    }
  }
  
  public func cameraControllerDidFinishWithResult(viewMode: IDCameraController.ViewMode, result: FaceIDMessage) {
    DispatchQueue.main.async { [weak self] in
      guard let self = self else { return }
      
      self.isInProgress = false
      self.currentViewController?.dismiss(animated: true) {
        self.currentViewController = nil
      }
      
      var faceIDResultMap: [String: Any] = [:]
      
      if let faceIDResult = result.faceIDResult {
        faceIDResultMap["verified"] = faceIDResult.verified
        faceIDResultMap["matchScore"] = faceIDResult.matchScore
        faceIDResultMap["transactionID"] = faceIDResult.transactionID ?? ""
        faceIDResultMap["userID"] = faceIDResult.userID ?? ""
        faceIDResultMap["method"] = methodTypeToString(faceIDResult.method)
        faceIDResultMap["header"] = faceIDResult.header ?? ""
        faceIDResultMap["description"] = faceIDResult.description ?? ""
        faceIDResultMap["listNames"] = faceIDResult.listNames ?? ""
        faceIDResultMap["listIds"] = faceIDResult.listIds ?? ""
        
        // Add identification-specific fields if available
        if let registrationTransactionID = faceIDResult.registrationTransactionID {
          faceIDResultMap["registrationTransactionID"] = registrationTransactionID
        }
        
        if let referencePhoto = faceIDResult.referencePhoto,
           let photoData = referencePhoto.jpegData(compressionQuality: 0.8) {
          faceIDResultMap["referencePhoto"] = photoData.base64EncodedString()
        }
        
        if let metadata = faceIDResult.metadata {
          var metadataMap: [String: Any] = [:]
          for (key, anyValue) in metadata {
            if let value = anyValue?.value {
              metadataMap[key] = value
            }
          }
          faceIDResultMap["metadata"] = metadataMap
        }
      }
      
      // Build liveness result dictionary separately
      var livenessResultDict: [String: Any]? = nil
      if let livenessResult = result.livenessResult {
        livenessResultDict = [
          "assessmentValue": livenessResult.assessmentValue ?? 0.0,
          "assessmentDescription": livenessResult.assessmentDescription ?? "",
          "probability": livenessResult.probability ?? 0.0,
          "quality": livenessResult.quality ?? 0.0,
          "livenessScore": livenessResult.livenessScore ?? 0.0,
          "transactionID": livenessResult.transactionID ?? ""
        ]
      }
      
      // Build face ID message dictionary
      let faceIDMessage: [String: Any] = [
        "success": !result.isFailed,
        "message": result.isFailed ? "Face recognition failed" : "Face recognition completed",
        "faceIDResult": faceIDResultMap.isEmpty ? nil : faceIDResultMap,
        "livenessResult": livenessResultDict
      ]
      
      // Create raw server response data (like Android)
      let rawResponseData = self.createRawFaceRecognitionResponse(faceIDResult: result.faceIDResult, livenessResult: result.livenessResult)
      
      self.channel?.invokeMethod("onResult", arguments: rawResponseData)
    }
  }
  
  public func cameraControllerUserPressedBackButton() {
    DispatchQueue.main.async { [weak self] in
      self?.channel?.invokeMethod("onBackButtonPressed", arguments: nil)
    }
  }
  
  public func cameraControllerWillDismiss() {
    DispatchQueue.main.async { [weak self] in
      self?.channel?.invokeMethod("onWillDismiss", arguments: nil)
    }
  }
  
  public func cameraControllerDidDismiss() {
    DispatchQueue.main.async { [weak self] in
      guard let self = self else { return }
      self.isInProgress = false
      self.currentViewController = nil
      self.channel?.invokeMethod("onDidDismiss", arguments: nil)
    }
  }

  public func onFaceDirectiveChanged(directive: FaceDirective) {
    DispatchQueue.main.async { [weak self] in
      self?.channel?.invokeMethod("onFaceDirectiveChanged", arguments: ["directive": "\(directive)"])
    }
  }
}

// MARK: - ActiveCameraController Delegate (Liveness)
extension LivenessFlutterPlugin: ActiveCameraControllerDelegate {
  public func onResult(result: FaceIDMessage) {
    DispatchQueue.main.async { [weak self] in
      guard let self = self else { return }
      
      self.isInProgress = false
      self.currentViewController?.dismiss(animated: true) {
        self.currentViewController = nil
      }
      
      // Debug logging for FaceIDMessage
      print("🎭 ========== iOS ACTIVE LIVENESS DELEGATE CALLED ==========")
      print("📊 FaceIDMessage.isFailed: \(result.isFailed)")
      print("📊 FaceIDMessage.faceIDResult: \(result.faceIDResult != nil ? "present" : "nil")")
      print("📊 FaceIDMessage.livenessResult: \(result.livenessResult != nil ? "present" : "nil")")
      print("📊 FaceIDMessage.activeLivenessResult: \(result.activeLivenessResult != nil ? "present" : "nil")")
      
      // Create comprehensive result map with ALL available data
      var faceIDMessageDict: [String: Any] = [
        "success": !result.isFailed,
        "message": result.isFailed ? "Active liveness failed" : "Active liveness completed",
        "isFailed": result.isFailed
      ]
      
      var resultMap: [String: Any] = [
        "status": result.isFailed ? "failure" : "success"
      ]
      
      // Add FaceIDResult if available (contains server response data)
      if let faceIDResult = result.faceIDResult {
        print("🔍 Processing FaceIDResult...")
        var faceIDResultDict: [String: Any] = [
          "verified": faceIDResult.verified,
          "matchScore": faceIDResult.matchScore,
          "transactionID": faceIDResult.transactionID ?? "",
          "userID": faceIDResult.userID ?? "",
          "method": methodTypeToString(faceIDResult.method),
          "header": faceIDResult.header ?? "",
          "description": faceIDResult.description ?? "",
          "listNames": faceIDResult.listNames ?? "",
          "listIds": faceIDResult.listIds ?? "",
          "registrationTransactionID": faceIDResult.registrationTransactionID ?? ""
        ]
        
        // Add error if present
        if let error = faceIDResult.error {
          faceIDResultDict["error"] = [
            "code": FaceSdkErrorName.code(for: error) ?? "\(error)",
            "message": error.localizedDescription
          ]
        }
        
        // Convert reference photo to base64 if present
        if let referencePhoto = faceIDResult.referencePhoto {
          if let imageData = referencePhoto.jpegData(compressionQuality: 0.8) {
            faceIDResultDict["referencePhotoBase64"] = imageData.base64EncodedString()
          }
        }
        
        // CRITICAL: Add raw server response from metadata
        if let metadata = faceIDResult.metadata {
          print("🌐 ========== RAW SERVER RESPONSE METADATA ==========")
          var metadataDict: [String: Any] = [:]
          for (key, value) in metadata {
            if let udentifyAny = value {
              let convertedValue = convertUdentifyAnyToSwift(udentifyAny)
              metadataDict[key] = convertedValue
            }
          }
          faceIDResultDict["metadata"] = metadataDict
          faceIDResultDict["rawServerResponse"] = metadataDict
          print("✅ Raw server response captured in metadata")
          print("================================================")
        } else {
          print("⚠️ No metadata found in FaceIDResult")
        }
        
        faceIDMessageDict["faceIDResult"] = faceIDResultDict
      } else {
        print("⚠️ No FaceIDResult in response")
      }
      
      // Add LivenessResult if available (passive liveness data)
      if let livenessResult = result.livenessResult {
        print("🔍 Processing LivenessResult...")
        var livenessResultDict: [String: Any] = [
          "assessmentValue": livenessResult.assessmentValue ?? 0.0,
          "assessmentDescription": livenessResult.assessmentDescription ?? "",
          "probability": livenessResult.probability ?? 0.0,
          "quality": livenessResult.quality ?? 0.0,
          "livenessScore": livenessResult.livenessScore ?? 0.0,
          "transactionID": livenessResult.transactionID ?? ""
        ]
        
        // Add error if present
        if let error = livenessResult.error {
          livenessResultDict["error"] = [
            "code": FaceSdkErrorName.code(for: error) ?? "\(error)",
            "message": error.localizedDescription
          ]
        }
        
        // Add assessment result
        let assessment = livenessResult.assessment()
        livenessResultDict["assessment"] = assessment.description
        
        faceIDMessageDict["livenessResult"] = livenessResultDict
      } else {
        print("⚠️ No LivenessResult in response")
      }
      
      // Add ActiveLivenessResult if available (gesture results)
      if let activeLivenessResult = result.activeLivenessResult {
        print("🔍 Processing ActiveLivenessResult...")
        var activeLivenessResultDict: [String: Any] = [
          "transactionID": activeLivenessResult.transactionID ?? "",
          "gestureResult": activeLivenessResult.gestureResult ?? [:]
        ]
        
        // Add error if present
        if let error = activeLivenessResult.error {
          activeLivenessResultDict["error"] = [
            "code": FaceSdkErrorName.code(for: error) ?? "\(error)",
            "message": error.localizedDescription
          ]
        }
        
        // Log gesture results for debugging
        if let gestureResult = activeLivenessResult.gestureResult {
          print("🎭 Gesture Results:")
          for (gesture, success) in gestureResult {
            print("   \(gesture): \(success)")
          }
        }
        
        faceIDMessageDict["activeLivenessResult"] = activeLivenessResultDict
      } else {
        print("⚠️ No ActiveLivenessResult in response")
      }
      
      // Create raw server response data (like Android)
      let rawResponseData = self.createRawActiveLivenessResponse(result: result)
      
      // Debug final result being sent to Flutter
      print("📤 ========== SENDING RAW DATA TO FLUTTER ==========")
      print("====================================================")
      
      // Send raw response to Flutter (like Android)
      self.channel?.invokeMethod("onActiveLivenessResult", arguments: rawResponseData)
    }
  }
  
  public func onVideoTaken() {
    print("📹 iOS: onVideoTaken delegate called")
    DispatchQueue.main.async { [weak self] in
      // Mirrors Android's onPhotoTaken, fired when the active/hybrid liveness camera
      // finishes capturing and before the result comes back from the server. This is
      // the iOS equivalent of the 2 Android call sites in startActiveLiveness/
      // startHybridLiveness's FaceRecognizer proxies.
      self?.channel?.invokeMethod("onPhotoTaken", arguments: nil)
      self?.channel?.invokeMethod("onVideoTaken", arguments: nil)
    }
  }
  
  public func onFailure(error: Error) {
    print("❌ iOS: onFailure delegate called with error: \(error.localizedDescription)")
    DispatchQueue.main.async { [weak self] in
      guard let self = self else { return }
      
      self.isInProgress = false
      self.currentViewController?.dismiss(animated: true) {
        self.currentViewController = nil
      }
      
      let errorMap: [String: Any] = [
        "code": FaceSdkErrorName.code(for: error) ?? "ACTIVE_LIVENESS_ERROR",
        "message": error.localizedDescription
      ]
      
      self.channel?.invokeMethod("onActiveLivenessFailure", arguments: errorMap)
    }
  }
  
  public func backButtonPressed() {
    DispatchQueue.main.async { [weak self] in
      self?.channel?.invokeMethod("onBackButtonPressed", arguments: nil)
    }
  }
  
  public func willDismiss() {
    DispatchQueue.main.async { [weak self] in
      self?.channel?.invokeMethod("onWillDismiss", arguments: nil)
    }
  }
  
  public func didDismiss() {
    print("✅ iOS: didDismiss delegate called")
    DispatchQueue.main.async { [weak self] in
      guard let self = self else { return }
      self.isInProgress = false
      self.currentViewController = nil
      self.channel?.invokeMethod("onDidDismiss", arguments: nil)
    }
  }

  public func onActiveLivenessDirectiveChanged(directive: ActiveLivenessDirective) {
    DispatchQueue.main.async { [weak self] in
      self?.channel?.invokeMethod("onActiveLivenessDirectiveChanged", arguments: ["directive": "\(directive)"])
    }
  }
}
#endif