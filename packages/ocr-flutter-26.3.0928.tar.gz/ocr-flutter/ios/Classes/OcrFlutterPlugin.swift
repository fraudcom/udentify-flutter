@preconcurrency import Flutter
import udentify_core_flutter
import UIKit
import UdentifyCommons
import UdentifyOCR

final class ThreadSafeFlutterResult: @unchecked Sendable {
    private var result: FlutterResult?
    private let lock = NSLock()

    init(_ result: @escaping FlutterResult) {
        self.result = result
    }

    func send(_ value: (any Sendable)?) {
        lock.lock()
        defer { lock.unlock() }
        guard let result = self.result else { return }
        self.result = nil
        DispatchQueue.main.async {
            result(value)
        }
    }
}

public class OcrFlutterPlugin: NSObject, @preconcurrency FlutterPlugin, UIImagePickerControllerDelegate, UINavigationControllerDelegate, @unchecked Sendable {
    
    private var ocrCameraController: OCRCameraViewController?
    private var hologramCameraController: HologramCameraViewControllerV2?
    
    private var channel: FlutterMethodChannel?
    
    private var lastCapturedFrontImage: UIImage?
    private var lastCapturedBackImage: UIImage?
    
    private var lastCapturedFrontImagePath: String?
    private var lastCapturedBackImagePath: String?

    // Take photo result handler
    private var takePhotoResult: FlutterResult?

    // State captured from the most recent startOCRCamera call so onDocumentScan can, when
    // livenessMode was requested, automatically run the OCR+document-liveness check once
    // capture completes (mirroring Android's isDocumentLivenessActive credential flag - iOS's
    // OCRCameraViewController.instantiate(withApiCallDisabled:...) has no equivalent flag and
    // never calls the API itself, so the plugin has to trigger it explicitly).
    private var cameraLivenessModeActive: Bool = false
    private var cameraServerURL: String?
    private var cameraTransactionID: String?
    private var cameraCountry: Country?
    private var cameraDocumentType: OCRDocumentType?
    private var cameraDocumentSide: OCRDocumentSide = .bothSides
    private var didTriggerCameraLivenessCheck: Bool = false

    // The UI configuration the app last set. Process-wide, like the SDK's own settings provider: a second
    // Flutter engine (a headless one from a background task, say) creates its own plugin instance and must
    // neither reset the settings nor take them with it when it is destroyed.
    private static var sharedUIConfiguration: [String: any Sendable]?
    private var uiConfiguration: [String: any Sendable]? {
        get { Self.sharedUIConfiguration }
        set { Self.sharedUIConfiguration = newValue }
    }
    
    public override init() {
        super.init()
        // Never over an app's configuration: this runs for every engine's plugin instance.
        if Self.sharedUIConfiguration == nil {
            Self.applyOCRSettings()
        }
    }
    
    private static func applyOCRSettings() {
        let bundle = UdentifyLanguagePreference.localizedBundle(for: Bundle(for: OcrFlutterPlugin.self))
        let customSettings = CustomOCRSettings(localizationBundle: bundle, uiConfig: sharedUIConfiguration)
        OCRSettingsProvider.getInstance().currentSettings = customSettings
    }
    
    /// The SDK's own error name for an `OCRError`, in the same vocabulary the Android SDK reports
    /// (its `ERR_OCR_*` string resources), so a failure reads the same on both platforms. `nil` for
    /// an error the SDK did not raise; callers then keep the code they always sent.
    static func sdkErrorCode(_ error: Error) -> String? {
        guard let ocrError = error as? OCRError else { return nil }
        switch ocrError {
        case .Unknown: return "ERR_UNKNOWN"
        case .api: return "ERR_OCR_API_ERROR"
        case .other: return "ERR_OCR_OTHER_ERROR"
        case .missingOcrResponse: return "ERR_OCR_MISSING_RESPONSE"
        case .missingDocumentLivenessResponse: return "ERR_OCR_MISSING_DOCUMENT_LIVENESS_RESPONSE"
        case .missingRequiredParameters: return "ERR_OCR_MISSING_PARAMETERS"
        @unknown default: return nil
        }
    }

    /// Arguments for the failure events: the SDK's message as before, plus its error name when it has one.
    static func failureArguments(_ error: Error) -> [String: Any] {
        var arguments: [String: Any] = ["error": error.localizedDescription]
        if let code = sdkErrorCode(error) { arguments["errorCode"] = code }
        return arguments
    }

    public static func register(with registrar: FlutterPluginRegistrar) {
        let channel = FlutterMethodChannel(name: "ocr_flutter", binaryMessenger: registrar.messenger())
        let instance = OcrFlutterPlugin()
        instance.channel = channel
        registrar.addMethodCallDelegate(instance, channel: channel)

        // In-call LiveKYC OCR gets the same bundle and styling as the standalone screen. The
        // installer re-reads `uiConfiguration` when it runs, so a config set later still applies.
        UdentifyLiveKYCModuleSettings.installOCRSettings = {
            OcrFlutterPlugin.applyOCRSettings()
        }
    }
    
    public func handle(_ call: FlutterMethodCall, result: @escaping FlutterResult) {
        switch call.method {
        case "startOCRCamera":
            handleStartOCRCamera(call, result: result)
        case "performOCR":
            handlePerformOCR(call, result: result)
        case "startHologramCamera":
            handleStartHologramCamera(call, result: result)
        case "uploadHologramVideo":
            handleUploadHologramVideo(call, result: result)
        case "performDocumentLiveness":
            handlePerformDocumentLiveness(call, result: result)
        case "performOCRAndDocumentLiveness":
            handlePerformOCRAndDocumentLiveness(call, result: result)
        case "setOCRUIConfig":
            handleSetOCRUIConfig(call, result: result)
        case "dismissOCRCamera":
            handleDismissOCRCamera(result)
        case "dismissHologramCamera":
            handleDismissHologramCamera(result)
        case "performIQA":
            handlePerformIQA(call, result: result)
        case "takePhoto":
            handleTakePhoto(result)
        default:
            result(FlutterError(code: "UNIMPLEMENTED", 
                               message: "Method not implemented: \(call.method)", 
                               details: nil))
        }
    }
    
    // MARK: - OCR Methods
    
    private func handleStartOCRCamera(_ call: FlutterMethodCall, result: @escaping FlutterResult) {
        let threadSafeResult = ThreadSafeFlutterResult(result)

        guard let args = call.arguments as? [String: any Sendable],
              let serverURL = args["serverURL"] as? String,
              let transactionID = args["transactionID"] as? String,
              let documentTypeString = args["documentType"] as? String else {
            threadSafeResult.send(FlutterError(code: "INVALID_ARGUMENTS", message: "Missing required parameters", details: nil))
            return
        }
        
        let countryString = args["country"] as? String
        let documentSideString = args["documentSide"] as? String ?? "bothSides"
        let manualCapture = args["manualCapture"] as? Bool ?? false
        // Android forces isDocumentLivenessActive(true) on the SDK credentials when this is
        // set, so its camera flow completes through the combined OCR+liveness callback
        // instead of the plain OCR one. iOS's OCRCameraViewController has no equivalent
        // credential flag (confirmed against UdentifyOCR's swiftinterface - instantiate(
        // withApiCallDisabled:...) never calls the API itself either way), so this is read
        // here and used to drive the same branching from onDocumentScan once capture completes.
        let livenessMode = args["livenessMode"] as? Bool ?? false

        // Refresh SDK settings so the crop ratio reaches OCRConfigs before the camera opens
        if let rawPhotoCropRatio = args["rawPhotoCropRatio"] as? Double {
            var mergedConfig = uiConfiguration ?? [:]
            mergedConfig["rawPhotoCropRatio"] = rawPhotoCropRatio
            uiConfiguration = mergedConfig
            let bundle = UdentifyLanguagePreference.localizedBundle(for: Bundle(for: OcrFlutterPlugin.self))
            let settings = CustomOCRSettings(localizationBundle: bundle, uiConfig: mergedConfig)
            OCRSettingsProvider.getInstance().currentSettings = settings
            debugPrint("OcrFlutterPlugin - rawPhotoCropRatio applied to OCRConfigs: \(settings.configs.rawPhotoCropRatio ?? -1)")
        }

        let documentType: OCRDocumentType
        switch documentTypeString {
        case "ID_CARD":
            documentType = OCRDocumentType.ID_CARD
        case "PASSPORT":
            documentType = OCRDocumentType.PASSPORT
        case "DRIVER_LICENSE":
            documentType = OCRDocumentType.DRIVE_LICENCE
        default:
            threadSafeResult.send(FlutterError(code: "INVALID_DOCUMENT_TYPE", message: "Invalid document type", details: nil))
            return
        }

        var country: Country? = nil
        if let countryString = countryString {
            country = CountryCodeMapper.toCountry(countryString)
        }

        let documentSide: OCRDocumentSide
        switch documentSideString {
        case "frontSide":
            documentSide = OCRDocumentSide.frontSide
        case "backSide":
            documentSide = OCRDocumentSide.backSide
        default:
            documentSide = OCRDocumentSide.bothSides
        }

        let capturedCountry = country
        
        DispatchQueue.main.async { [weak self, capturedCountry, threadSafeResult] in
            guard let strongSelf = self else {
                threadSafeResult.send(FlutterError(code: "PLUGIN_DEALLOCATED", message: "Plugin was deallocated", details: nil))
                return
            }

            strongSelf.cameraLivenessModeActive = livenessMode
            strongSelf.cameraServerURL = serverURL
            strongSelf.cameraTransactionID = transactionID
            strongSelf.cameraCountry = capturedCountry
            strongSelf.cameraDocumentType = documentType
            strongSelf.cameraDocumentSide = documentSide
            strongSelf.didTriggerCameraLivenessCheck = false

            strongSelf.ocrCameraController = OCRCameraViewController.instantiate(
                withApiCallDisabled: strongSelf,
                serverURL: serverURL,
                transactionID: transactionID,
                documentType: documentType,
                country: capturedCountry,
                documentSide: documentSide,
                manualCapture: manualCapture
            )
            
            if let controller = strongSelf.ocrCameraController {
                controller.modalPresentationStyle = .fullScreen
                
                if let viewController = UdentifyPresenter.topViewController() {
                    viewController.present(controller, animated: true) {
                        threadSafeResult.send(true)
                    }
                } else {
                    threadSafeResult.send(FlutterError(code: "NO_VIEW_CONTROLLER", message: "No view controller available", details: nil))
                }
            } else {
                threadSafeResult.send(FlutterError(code: "INSTANTIATION_FAILED", message: "Failed to instantiate OCR camera controller", details: nil))
            }
        }
    }
    
    /// Decodes a base64-encoded image string into a UIImage.
    /// Accepts raw base64 (the documented format) and tolerates an optional
    /// "data:image/...;base64," data-URI prefix. Returns nil for null/empty/invalid input.
    private func decodeBase64Image(_ base64String: String?) -> UIImage? {
        // The camera-capture flow sends the sentinel "IMAGE_PATH_STORED" instead of real
        // image data; treat it (and null/empty) as "no provided photo" so performOCR falls
        // back to the natively-stored capture.
        guard let base64String = base64String, !base64String.isEmpty,
              base64String != "IMAGE_PATH_STORED" else { return nil }
        let cleaned: String
        if let range = base64String.range(of: "base64,") {
            cleaned = String(base64String[range.upperBound...])
        } else {
            cleaned = base64String
        }
        guard let data = Data(base64Encoded: cleaned, options: .ignoreUnknownCharacters) else { return nil }
        return UIImage(data: data)
    }

    private func handlePerformOCR(_ call: FlutterMethodCall, result: @escaping FlutterResult) {
        let threadSafeResult = ThreadSafeFlutterResult(result)

        guard let args = call.arguments as? [String: any Sendable],
              let serverURL = args["serverURL"] as? String,
              let transactionID = args["transactionID"] as? String,
              let documentTypeString = args["documentType"] as? String else {
            threadSafeResult.send(FlutterError(code: "INVALID_ARGUMENTS", message: "Missing required parameters", details: nil))
            return
        }
        
        let countryString = args["country"] as? String

        // Externally-provided photos (base64-encoded JPEG, no data-URI prefix).
        // When supplied, these take precedence over camera-captured stored images.
        let providedFrontPhoto = args["frontSidePhoto"] as? String
        let providedBackPhoto = args["backSidePhoto"] as? String
        let requestTimeoutSeconds = Self.requestTimeoutSeconds(args)

        debugPrint("OcrFlutterPlugin - performOCR called")
        debugPrint("OcrFlutterPlugin - Stored front path: \(lastCapturedFrontImagePath != nil)")
        debugPrint("OcrFlutterPlugin - Stored back path: \(lastCapturedBackImagePath != nil)")
        debugPrint("OcrFlutterPlugin - Stored front image: \(lastCapturedFrontImage != nil)")
        debugPrint("OcrFlutterPlugin - Stored back image: \(lastCapturedBackImage != nil)")
        
        let documentType: OCRDocumentType
        switch documentTypeString {
        case "ID_CARD":
            documentType = OCRDocumentType.ID_CARD
        case "PASSPORT":
            documentType = OCRDocumentType.PASSPORT
        case "DRIVER_LICENSE":
            documentType = OCRDocumentType.DRIVE_LICENCE
        default:
            threadSafeResult.send(FlutterError(code: "INVALID_DOCUMENT_TYPE", message: "Invalid document type", details: nil))
            return
        }
        
        var country: Country? = nil
        if let countryString = countryString {
            country = CountryCodeMapper.toCountry(countryString)
        }
        
        let capturedCountry = country
        
        DispatchQueue.main.async { [weak self] in
            guard let self = self else { return }
            
            let providedFrontImage = self.decodeBase64Image(providedFrontPhoto)
            let providedBackImage = self.decodeBase64Image(providedBackPhoto)

            let payload: DocumentScanPayload
            if providedFrontImage != nil || providedBackImage != nil {
                debugPrint("OcrFlutterPlugin - Using externally-provided photos for performOCR")
                payload = .images(front: providedFrontImage, back: providedBackImage)
            } else if self.lastCapturedFrontImagePath != nil || self.lastCapturedBackImagePath != nil {
                debugPrint("OcrFlutterPlugin - Using stored image paths for performOCR")
                payload = .imagePaths(front: self.lastCapturedFrontImagePath, back: self.lastCapturedBackImagePath)
            } else if self.lastCapturedFrontImage != nil || self.lastCapturedBackImage != nil {
                debugPrint("OcrFlutterPlugin - Using stored UIImage objects for performOCR")
                payload = .images(front: self.lastCapturedFrontImage, back: self.lastCapturedBackImage)
            } else {
                threadSafeResult.send(FlutterError(code: "NO_IMAGES", message: "No images available for OCR", details: nil))
                return
            }

            OCRCameraViewController.performOCR(
                serverURL: serverURL,
                transactionID: transactionID,
                documentPayload: payload,
                country: capturedCountry,
                documentType: documentType,
                requestTimeout: requestTimeoutSeconds
            ) { [weak self] (response, error) in
                DispatchQueue.main.async {
                    guard let self = self else { return }
                    
                    self.clearStoredData()
                    
                    if let error = error {
                        threadSafeResult.send(FlutterError(code: OcrFlutterPlugin.sdkErrorCode(error) ?? "OCR_FAILED", message: error.localizedDescription, details: nil))
                    } else if let response = response {
                        let responseDict = self.convertOCRResponseToDict(response, transactionID: transactionID)
                        threadSafeResult.send(responseDict)
                    } else {
                        threadSafeResult.send(FlutterError(code: "NO_RESPONSE", message: "No response received", details: nil))
                    }
                }
            }
        }
    }
    
    // MARK: - Hologram Methods
    
    private func handleStartHologramCamera(_ call: FlutterMethodCall, result: @escaping FlutterResult) {
        let threadSafeResult = ThreadSafeFlutterResult(result)

        guard let args = call.arguments as? [String: any Sendable],
              let serverURL = args["serverURL"] as? String,
              let transactionID = args["transactionID"] as? String else {
            threadSafeResult.send(FlutterError(code: "INVALID_ARGUMENTS", message: "Missing required parameters", details: nil))
            return
        }
        
        let countryString = args["country"] as? String
        let logLevelString = args["logLevel"] as? String ?? "warning"
        let noFlashDuration = args["noFlashDuration"] as? Double
        let flashDuration = args["flashDuration"] as? Double
        let totalDuration = args["totalDuration"] as? Double
        let bitrate = args["bitrate"] as? Double

        var country: Country? = nil
        if let countryString = countryString {
            country = CountryCodeMapper.toCountry(countryString)
        }
        
        let logLevel: LogLevel
        switch logLevelString.lowercased() {
        case "debug":
            logLevel = LogLevel.debug
        case "info":
            logLevel = LogLevel.info
        case "warning":
            logLevel = LogLevel.warning
        case "error":
            logLevel = LogLevel.error
        default:
            logLevel = LogLevel.warning
        }
        
        DispatchQueue.main.async { [weak self] in
            guard let strongSelf = self else {
                threadSafeResult.send(FlutterError(code: "PLUGIN_DEALLOCATED", message: "Plugin was deallocated", details: nil))
                return
            }
            
            strongSelf.hologramCameraController = HologramCameraViewControllerV2.instantiate(
                delegate: strongSelf,
                serverURL: serverURL,
                transactionID: transactionID,
                country: country,
                noFlashDuration: noFlashDuration ?? 2,
                flashDuration: flashDuration ?? 3,
                totalDuration: totalDuration ?? 5,
                bitrate: bitrate,
                logLevel: logLevel
            )
            
            if let controller = strongSelf.hologramCameraController {
                controller.modalPresentationStyle = .fullScreen
                
                if let viewController = UdentifyPresenter.topViewController() {
                    viewController.present(controller, animated: true) {
                        threadSafeResult.send(true)
                    }
                } else {
                    threadSafeResult.send(FlutterError(code: "NO_VIEW_CONTROLLER", message: "No view controller available", details: nil))
                }
            } else {
                threadSafeResult.send(FlutterError(code: "INSTANTIATION_FAILED", message: "Failed to instantiate hologram camera controller", details: nil))
            }
        }
    }
    
    private func handleUploadHologramVideo(_ call: FlutterMethodCall, result: @escaping FlutterResult) {
        let threadSafeResult = ThreadSafeFlutterResult(result)

        guard let args = call.arguments as? [String: any Sendable],
              let serverURL = args["serverURL"] as? String,
              let transactionID = args["transactionID"] as? String,
              let videoUrlStrings = args["videoUrls"] as? [String] else {
            threadSafeResult.send(FlutterError(code: "INVALID_ARGUMENTS", message: "Missing required parameters", details: nil))
            return
        }
        
        let videoUrls = videoUrlStrings.compactMap { URL(string: $0) }
        guard let videoUrl = videoUrls.first else {
            threadSafeResult.send(FlutterError(code: "INVALID_ARGUMENTS", message: "No valid video URL provided", details: nil))
            return
        }

        DispatchQueue.main.async { [weak self] in
            HologramCameraViewControllerV2.uploadHologramVideo(
                serverURL: serverURL,
                transactionID: transactionID,
                path: videoUrl
            ) { [weak self] (response) in
                if let error = response.error {
                    threadSafeResult.send(FlutterError(code: OcrFlutterPlugin.sdkErrorCode(error) ?? "HOLOGRAM_UPLOAD_FAILED", message: error.localizedDescription, details: nil))
                } else {
                    let responseDict = self?.convertHologramResponseToDict(response, transactionID: transactionID) ?? [:]
                    threadSafeResult.send(responseDict)
                }
            }
        }
    }
    
    // MARK: - Document Liveness Methods
    
    private func handlePerformDocumentLiveness(_ call: FlutterMethodCall, result: @escaping FlutterResult) {
        let threadSafeResult = ThreadSafeFlutterResult(result)

        guard let args = call.arguments as? [String: any Sendable],
              let serverURL = args["serverURL"] as? String,
              let transactionID = args["transactionID"] as? String else {
            threadSafeResult.send(FlutterError(code: "INVALID_ARGUMENTS", message: "Missing required parameters", details: nil))
            return
        }

        // Externally-provided photos (base64-encoded JPEG, no data-URI prefix). When supplied,
        // these take precedence over camera-captured stored images, matching performOCR.
        let providedFrontPhoto = args["frontSidePhoto"] as? String
        let providedBackPhoto = args["backSidePhoto"] as? String
        let requestTimeoutSeconds = Self.requestTimeoutSeconds(args)

        debugPrint("OcrFlutterPlugin - performDocumentLiveness called")
        debugPrint("OcrFlutterPlugin - Stored front path: \(lastCapturedFrontImagePath != nil)")
        debugPrint("OcrFlutterPlugin - Stored back path: \(lastCapturedBackImagePath != nil)")

        DispatchQueue.main.async { [weak self] in
            guard let self = self else { return }

            let providedFrontImage = self.decodeBase64Image(providedFrontPhoto)
            let providedBackImage = self.decodeBase64Image(providedBackPhoto)

            let payload: DocumentScanPayload
            if providedFrontImage != nil || providedBackImage != nil {
                debugPrint("OcrFlutterPlugin - Using externally-provided photos for performDocumentLiveness")
                payload = .images(front: providedFrontImage, back: providedBackImage)
            } else if self.lastCapturedFrontImagePath != nil || self.lastCapturedBackImagePath != nil {
                debugPrint("OcrFlutterPlugin - Using stored image paths for performDocumentLiveness")
                payload = .imagePaths(front: self.lastCapturedFrontImagePath, back: self.lastCapturedBackImagePath)
            } else if self.lastCapturedFrontImage != nil || self.lastCapturedBackImage != nil {
                debugPrint("OcrFlutterPlugin - Using stored UIImage objects for performDocumentLiveness")
                payload = .images(front: self.lastCapturedFrontImage, back: self.lastCapturedBackImage)
            } else {
                threadSafeResult.send(FlutterError(code: "NO_IMAGES", message: "No images available for document liveness", details: nil))
                return
            }

            OCRCameraViewController.performDocumentLiveness(
                serverURL: serverURL,
                transactionID: transactionID,
                documentPayload: payload,
                requestTimeout: requestTimeoutSeconds
            ) { [weak self] (response) in
                DispatchQueue.main.async {
                    guard let self = self else { return }
                    
                    self.clearStoredData()
                    
                    if response.isFailed {
                        threadSafeResult.send(FlutterError(code: "DOCUMENT_LIVENESS_FAILED", message: "Document liveness check failed", details: nil))
                    } else {
                        let responseDict = self.convertDocumentLivenessResponseToDict(response, transactionID: transactionID)
                        threadSafeResult.send(responseDict)
                    }
                }
            }
        }
    }
    
    private func handlePerformOCRAndDocumentLiveness(_ call: FlutterMethodCall, result: @escaping FlutterResult) {
        let threadSafeResult = ThreadSafeFlutterResult(result)

        guard let args = call.arguments as? [String: any Sendable],
              let serverURL = args["serverURL"] as? String,
              let transactionID = args["transactionID"] as? String,
              let documentTypeString = args["documentType"] as? String else {
            threadSafeResult.send(FlutterError(code: "INVALID_ARGUMENTS", message: "Missing required parameters", details: nil))
            return
        }
        
        let countryString = args["country"] as? String

        // Externally-provided photos (base64-encoded JPEG, no data-URI prefix). When supplied,
        // these take precedence over camera-captured stored images, matching performOCR.
        let providedFrontPhoto = args["frontSidePhoto"] as? String
        let providedBackPhoto = args["backSidePhoto"] as? String
        let requestTimeoutSeconds = Self.requestTimeoutSeconds(args)

        debugPrint("OcrFlutterPlugin - performOCRAndDocumentLiveness called")
        debugPrint("OcrFlutterPlugin - Stored front path: \(lastCapturedFrontImagePath != nil)")
        debugPrint("OcrFlutterPlugin - Stored back path: \(lastCapturedBackImagePath != nil)")

        let documentType: OCRDocumentType
        switch documentTypeString {
        case "ID_CARD":
            documentType = OCRDocumentType.ID_CARD
        case "PASSPORT":
            documentType = OCRDocumentType.PASSPORT
        case "DRIVER_LICENSE":
            documentType = OCRDocumentType.DRIVE_LICENCE
        default:
            threadSafeResult.send(FlutterError(code: "INVALID_DOCUMENT_TYPE", message: "Invalid document type", details: nil))
            return
        }
        
        var country: Country? = nil
        if let countryString = countryString {
            country = CountryCodeMapper.toCountry(countryString)
        }
        
        let capturedCountry = country
        
        DispatchQueue.main.async { [weak self] in
            guard let self = self else { return }

            let providedFrontImage = self.decodeBase64Image(providedFrontPhoto)
            let providedBackImage = self.decodeBase64Image(providedBackPhoto)

            let payload: DocumentScanPayload
            if providedFrontImage != nil || providedBackImage != nil {
                debugPrint("OcrFlutterPlugin - Using externally-provided photos for performOCRAndDocumentLiveness")
                payload = .images(front: providedFrontImage, back: providedBackImage)
            } else if self.lastCapturedFrontImagePath != nil || self.lastCapturedBackImagePath != nil {
                debugPrint("OcrFlutterPlugin - Using stored image paths for performOCRAndDocumentLiveness")
                payload = .imagePaths(front: self.lastCapturedFrontImagePath, back: self.lastCapturedBackImagePath)
            } else if self.lastCapturedFrontImage != nil || self.lastCapturedBackImage != nil {
                debugPrint("OcrFlutterPlugin - Using stored UIImage objects for performOCRAndDocumentLiveness")
                payload = .images(front: self.lastCapturedFrontImage, back: self.lastCapturedBackImage)
            } else {
                threadSafeResult.send(FlutterError(code: "NO_IMAGES", message: "No images available for OCR and document liveness", details: nil))
                return
            }

            OCRCameraViewController.performOCRAndDocumentLiveness(
                serverURL: serverURL,
                transactionID: transactionID,
                documentPayload: payload,
                country: capturedCountry,
                documentType: documentType,
                requestTimeout: requestTimeoutSeconds
            ) { [weak self] (response) in
                DispatchQueue.main.async {
                    guard let self = self else { return }
                    
                    self.clearStoredData()
                    
                    if response.isFailed {
                        threadSafeResult.send(FlutterError(code: "OCR_AND_DOCUMENT_LIVENESS_FAILED", message: "OCR and document liveness check failed", details: nil))
                    } else {
                        let responseDict = self.convertDocumentLivenessResponseToDict(response, transactionID: transactionID)
                        threadSafeResult.send(responseDict)
                    }
                }
            }
        }
    }

    // MARK: - UI Configuration
    
    private func handleSetOCRUIConfig(_ call: FlutterMethodCall, result: @escaping FlutterResult) {
        guard let configDict = call.arguments as? [String: any Sendable] else {
            result(FlutterError(code: "INVALID_ARGUMENTS", message: "Invalid configuration arguments", details: nil))
            return
        }
        
        uiConfiguration = configDict
        
        let bundle = UdentifyLanguagePreference.localizedBundle(for: Bundle(for: OcrFlutterPlugin.self))
        let customSettings = CustomOCRSettings(localizationBundle: bundle, uiConfig: configDict)
        OCRSettingsProvider.getInstance().currentSettings = customSettings
        
        result(nil)
    }
    
    // MARK: - Helper Methods
    
    /// The call's `requestTimeout` in seconds. Dart sends 30 when the app set none, which is also the SDK's own default;
    /// a missing or non-positive value leaves it at 30.
    private static func requestTimeoutSeconds(_ args: [String: any Sendable]) -> Double {
        let seconds = (args["requestTimeout"] as? NSNumber)?.doubleValue ?? 30
        return seconds > 0 ? seconds : 30
    }

    private func clearStoredData() {
        self.lastCapturedFrontImage = nil
        self.lastCapturedBackImage = nil
        self.lastCapturedFrontImagePath = nil
        self.lastCapturedBackImagePath = nil
    }
    
    private func topViewController() -> UIViewController? {
        return UdentifyPresenter.topViewController()
    }
    
    // MARK: - Response Conversion
    
    private func convertOCRResponseToDict(_ response: OCRResponse, transactionID: String) -> [String: any Sendable] {
        var resultDict: [String: any Sendable] = [:]
        resultDict["success"] = true
        resultDict["transactionID"] = transactionID
        resultDict["timestamp"] = Date().timeIntervalSince1970
        
        switch response {
        case .idCard(let idCardResponse):
            resultDict["responseType"] = "idCard"
            resultDict["documentType"] = "ID_CARD"
            
            var extractedData: [String: any Sendable] = [:]
            extractedData["firstName"] = idCardResponse.firstName ?? ""
            extractedData["lastName"] = idCardResponse.lastName ?? ""
            extractedData["documentNumber"] = idCardResponse.documentID ?? ""
            extractedData["identityNo"] = idCardResponse.identityNo ?? ""
            extractedData["expiryDate"] = idCardResponse.expiryDate ?? ""
            extractedData["birthDate"] = idCardResponse.birthDate ?? ""
            extractedData["nationality"] = idCardResponse.nationality ?? ""
            extractedData["gender"] = idCardResponse.gender ?? ""
            extractedData["countryCode"] = idCardResponse.countryCode ?? ""
            extractedData["documentIssuer"] = idCardResponse.documentIssuer ?? ""
            extractedData["motherName"] = idCardResponse.motherName ?? ""
            extractedData["fatherName"] = idCardResponse.fatherName ?? ""
            extractedData["isDocumentExpired"] = idCardResponse.isOCRDocumentExpired ?? false
            extractedData["isIDValid"] = idCardResponse.isOCRIDValid ?? false
            extractedData["hasPhoto"] = idCardResponse.hasOCRPhoto ?? false
            extractedData["hasSignature"] = idCardResponse.hasOCRSignature ?? false
            extractedData["nativeFirstName"] = idCardResponse.nativeFirstName ?? ""
            extractedData["nativeLastName"] = idCardResponse.nativeLastName ?? ""
            extractedData["nativeGender"] = idCardResponse.nativeGender ?? ""
            
            if let faceImage = idCardResponse.faceImage {
                let imageData = faceImage.jpegData(compressionQuality: 0.8)
                extractedData["faceImage"] = imageData?.base64EncodedString() ?? ""
            }
            
            resultDict["extractedData"] = extractedData
            
            // Build old format for backward compatibility
            var idCardDict: [String: any Sendable] = [:]
            idCardDict["documentType"] = idCardResponse.documentType
            idCardDict["countryCode"] = idCardResponse.countryCode
            idCardDict["documentID"] = idCardResponse.documentID
            idCardDict["firstName"] = idCardResponse.firstName
            idCardDict["lastName"] = idCardResponse.lastName
            idCardDict["identityNo"] = idCardResponse.identityNo
            idCardDict["birthDate"] = idCardResponse.birthDate
            idCardDict["expiryDate"] = idCardResponse.expiryDate
            idCardDict["nationality"] = idCardResponse.nationality
            idCardDict["gender"] = idCardResponse.gender
            idCardDict["documentIssuer"] = idCardResponse.documentIssuer
            idCardDict["motherName"] = idCardResponse.motherName
            idCardDict["fatherName"] = idCardResponse.fatherName
            idCardDict["isOCRDocumentExpired"] = idCardResponse.isOCRDocumentExpired
            idCardDict["isOCRIDValid"] = idCardResponse.isOCRIDValid
            idCardDict["hasOCRPhoto"] = idCardResponse.hasOCRPhoto
            idCardDict["hasOCRSignature"] = idCardResponse.hasOCRSignature
            // Coalesce so the keys stay present when the server returns no
            // native-script data (nil values would drop the keys entirely)
            idCardDict["nativeFirstName"] = idCardResponse.nativeFirstName ?? ""
            idCardDict["nativeLastName"] = idCardResponse.nativeLastName ?? ""
            idCardDict["nativeGender"] = idCardResponse.nativeGender ?? ""
            if let faceImage = idCardResponse.faceImage,
               let imageData = faceImage.jpegData(compressionQuality: 0.8) {
                idCardDict["faceImage"] = imageData.base64EncodedString()
            }
            resultDict["idCardResponse"] = idCardDict
            
        case .driverLicense(let driverLicenseResponse):
            resultDict["responseType"] = "driverLicense"
            resultDict["documentType"] = "DRIVER_LICENSE"
            
            var extractedData: [String: any Sendable] = [:]
            extractedData["firstName"] = driverLicenseResponse.firstName ?? ""
            extractedData["lastName"] = driverLicenseResponse.lastName ?? ""
            extractedData["documentNumber"] = driverLicenseResponse.documentID ?? ""
            extractedData["identityNo"] = driverLicenseResponse.identityNo ?? ""
            extractedData["expiryDate"] = driverLicenseResponse.expiryDate ?? ""
            extractedData["birthDate"] = driverLicenseResponse.birthDate ?? ""
            extractedData["countryCode"] = driverLicenseResponse.countryCode ?? ""
            extractedData["issueDate"] = driverLicenseResponse.issueDate ?? ""
            extractedData["licenseType"] = driverLicenseResponse.ocrLicenceType ?? ""
            extractedData["city"] = driverLicenseResponse.city ?? ""
            extractedData["district"] = driverLicenseResponse.district ?? ""
            extractedData["isDocumentExpired"] = driverLicenseResponse.isOCRDocumentExpired ?? false
            extractedData["isIDValid"] = driverLicenseResponse.isOCRIDValid ?? false
            
            if let faceImage = driverLicenseResponse.faceImage {
                let imageData = faceImage.jpegData(compressionQuality: 0.8)
                extractedData["faceImage"] = imageData?.base64EncodedString() ?? ""
            }
            
            resultDict["extractedData"] = extractedData
            
            // Build old format for backward compatibility
            var driverLicenseDict: [String: any Sendable] = [:]
            driverLicenseDict["documentType"] = driverLicenseResponse.documentType
            driverLicenseDict["countryCode"] = driverLicenseResponse.countryCode
            driverLicenseDict["documentID"] = driverLicenseResponse.documentID
            driverLicenseDict["firstName"] = driverLicenseResponse.firstName
            driverLicenseDict["lastName"] = driverLicenseResponse.lastName
            driverLicenseDict["identityNo"] = driverLicenseResponse.identityNo
            driverLicenseDict["birthDate"] = driverLicenseResponse.birthDate
            driverLicenseDict["expiryDate"] = driverLicenseResponse.expiryDate
            driverLicenseDict["issueDate"] = driverLicenseResponse.issueDate
            driverLicenseDict["ocrLicenceType"] = driverLicenseResponse.ocrLicenceType
            driverLicenseDict["ocrQRLicenceID"] = driverLicenseResponse.ocrQRLicenceID
            driverLicenseDict["city"] = driverLicenseResponse.city
            driverLicenseDict["district"] = driverLicenseResponse.district
            driverLicenseDict["isOCRDocumentExpired"] = driverLicenseResponse.isOCRDocumentExpired
            driverLicenseDict["isOCRIDValid"] = driverLicenseResponse.isOCRIDValid
            if let faceImage = driverLicenseResponse.faceImage,
               let imageData = faceImage.jpegData(compressionQuality: 0.8) {
                driverLicenseDict["faceImage"] = imageData.base64EncodedString()
            }
            resultDict["driverLicenseResponse"] = driverLicenseDict
            
        case .passport(let passportResponse):
            resultDict["responseType"] = "passport"
            resultDict["documentType"] = "PASSPORT"

            var extractedData: [String: any Sendable] = [:]
            extractedData["firstName"] = passportResponse.firstName ?? ""
            extractedData["lastName"] = passportResponse.lastName ?? ""
            extractedData["documentNumber"] = passportResponse.documentID ?? ""
            extractedData["identityNo"] = passportResponse.identityNo ?? ""
            extractedData["expiryDate"] = passportResponse.expiryDate ?? ""
            extractedData["birthDate"] = passportResponse.birthDate ?? ""
            extractedData["nationality"] = passportResponse.nationality ?? ""
            extractedData["gender"] = passportResponse.gender ?? ""
            extractedData["countryCode"] = passportResponse.countryCode ?? ""
            extractedData["isDocumentExpired"] = passportResponse.isOCRDocumentExpired ?? false
            extractedData["isIDValid"] = passportResponse.isOCRIDValid ?? false
            extractedData["nativeFirstName"] = passportResponse.nativeFirstName ?? ""
            extractedData["nativeLastName"] = passportResponse.nativeLastName ?? ""
            extractedData["nativeGender"] = passportResponse.nativeGender ?? ""

            if let faceImage = passportResponse.faceImage {
                let imageData = faceImage.jpegData(compressionQuality: 0.8)
                extractedData["faceImage"] = imageData?.base64EncodedString() ?? ""
            }

            resultDict["extractedData"] = extractedData

            var passportDict: [String: any Sendable] = [:]
            passportDict["documentType"] = passportResponse.documentType
            passportDict["countryCode"] = passportResponse.countryCode
            passportDict["documentID"] = passportResponse.documentID
            passportDict["firstName"] = passportResponse.firstName
            passportDict["lastName"] = passportResponse.lastName
            passportDict["identityNo"] = passportResponse.identityNo
            passportDict["birthDate"] = passportResponse.birthDate
            passportDict["expiryDate"] = passportResponse.expiryDate
            passportDict["nationality"] = passportResponse.nationality
            passportDict["gender"] = passportResponse.gender
            passportDict["isOCRDocumentExpired"] = passportResponse.isOCRDocumentExpired
            passportDict["isOCRIDValid"] = passportResponse.isOCRIDValid
            passportDict["hasOCRSignature"] = passportResponse.hasOCRSignature
            passportDict["mrzString"] = passportResponse.mrzString
            passportDict["nativeFirstName"] = passportResponse.nativeFirstName ?? ""
            passportDict["nativeLastName"] = passportResponse.nativeLastName ?? ""
            passportDict["nativeGender"] = passportResponse.nativeGender ?? ""
            if let faceImage = passportResponse.faceImage,
               let imageData = faceImage.jpegData(compressionQuality: 0.8) {
                passportDict["faceImage"] = imageData.base64EncodedString()
            }
            resultDict["passportResponse"] = passportDict
        @unknown default:
            fatalError("")
        }
        
        return resultDict
    }
    
    private func convertDocumentLivenessResponseToDict(_ response: OCRAndDocumentLivenessResponse, transactionID: String) -> [String: any Sendable] {
        var resultDict: [String: any Sendable] = [:]
        resultDict["success"] = !response.isFailed
        resultDict["transactionID"] = transactionID
        resultDict["timestamp"] = Date().timeIntervalSince1970
        resultDict["isFailed"] = response.isFailed
        
        // Add front side liveness data
        if let frontData = response.documentLivenessDataFront?.documentLivenessResponse {
            let frontProbabilityString = frontData.aggregateDocumentLivenessProbability ?? "0"
            resultDict["frontSideProbability"] = Double(frontProbabilityString) ?? 0.0
            
            var frontSideResults: [[String: any Sendable]] = []
            if let pipelineResults = frontData.pipelineResults {
                for result in pipelineResults {
                    var resultDict: [String: any Sendable] = [:]
                    resultDict["name"] = result.name ?? ""
                    let probabilityString = result.documentLivenessProbability ?? "0"
                    resultDict["probability"] = Double(probabilityString) ?? 0.0
                    resultDict["calibration"] = result.calibration ?? ""
                    frontSideResults.append(resultDict)
                }
            }
            resultDict["frontSideResults"] = frontSideResults
        }
        
        // Add back side liveness data
        if let backData = response.documentLivenessDataBack?.documentLivenessResponse {
            let backProbabilityString = backData.aggregateDocumentLivenessProbability ?? "0"
            resultDict["backSideProbability"] = Double(backProbabilityString) ?? 0.0
            
            var backSideResults: [[String: any Sendable]] = []
            if let pipelineResults = backData.pipelineResults {
                for result in pipelineResults {
                    var resultDict: [String: any Sendable] = [:]
                    resultDict["name"] = result.name ?? ""
                    let probabilityString = result.documentLivenessProbability ?? "0"
                    resultDict["probability"] = Double(probabilityString) ?? 0.0
                    resultDict["calibration"] = result.calibration ?? ""
                    backSideResults.append(resultDict)
                }
            }
            resultDict["backSideResults"] = backSideResults
        }
        
        // Add OCR data if available
        if let ocrData = response.ocrData {
            var ocrDict: [String: any Sendable] = [:]
            if let ocrResponse = ocrData.ocrResponse {
                ocrDict["ocrResponse"] = convertOCRResponseToDict(ocrResponse, transactionID: transactionID)
            }
            if let error = ocrData.error {
                ocrDict["error"] = error
            }
            resultDict["ocrData"] = ocrDict
        }
        
        // Add document liveness data for compatibility
        if let frontData = response.documentLivenessDataFront {
            var frontDict: [String: any Sendable] = [:]
            if let frontResponse = frontData.documentLivenessResponse {
                var frontLivenessDict: [String: any Sendable] = [:]
                frontLivenessDict["aggregateDocumentLivenessProbability"] = frontResponse.aggregateDocumentLivenessProbability
                frontLivenessDict["aggregateDocumentImageQualityWarnings"] = frontResponse.aggregateDocumentImageQualityWarnings
                
                if let pipelineResults = frontResponse.pipelineResults {
                    var pipelineArray: [[String: any Sendable]] = []
                    for result in pipelineResults {
                        var pipelineDict: [String: any Sendable] = [:]
                        pipelineDict["name"] = result.name
                        pipelineDict["calibration"] = result.calibration
                        pipelineDict["documentLivenessScore"] = result.documentLivenessScore
                        pipelineDict["documentLivenessProbability"] = result.documentLivenessProbability
                        pipelineDict["documentStatusCode"] = result.documentStatusCode
                        pipelineArray.append(pipelineDict)
                    }
                    frontLivenessDict["pipelineResults"] = pipelineArray
                }
                frontDict["documentLivenessResponse"] = frontLivenessDict
            }
            if let error = frontData.error {
                frontDict["error"] = error
            }
            resultDict["documentLivenessDataFront"] = frontDict
        }
        
        if let backData = response.documentLivenessDataBack {
            var backDict: [String: any Sendable] = [:]
            if let backResponse = backData.documentLivenessResponse {
                var backLivenessDict: [String: any Sendable] = [:]
                backLivenessDict["aggregateDocumentLivenessProbability"] = backResponse.aggregateDocumentLivenessProbability
                backLivenessDict["aggregateDocumentImageQualityWarnings"] = backResponse.aggregateDocumentImageQualityWarnings
                
                if let pipelineResults = backResponse.pipelineResults {
                    var pipelineArray: [[String: any Sendable]] = []
                    for result in pipelineResults {
                        var pipelineDict: [String: any Sendable] = [:]
                        pipelineDict["name"] = result.name
                        pipelineDict["calibration"] = result.calibration
                        pipelineDict["documentLivenessScore"] = result.documentLivenessScore
                        pipelineDict["documentLivenessProbability"] = result.documentLivenessProbability
                        pipelineDict["documentStatusCode"] = result.documentStatusCode
                        pipelineArray.append(pipelineDict)
                    }
                    backLivenessDict["pipelineResults"] = pipelineArray
                }
                backDict["documentLivenessResponse"] = backLivenessDict
            }
            if let error = backData.error {
                backDict["error"] = error
            }
            resultDict["documentLivenessDataBack"] = backDict
        }
        
        return resultDict
    }
    
    private func convertHologramResponseToDict(_ response: HologramResponse, transactionID: String) -> [String: any Sendable] {
        var resultDict: [String: any Sendable] = [:]
        resultDict["success"] = response.error == nil
        resultDict["transactionID"] = transactionID
        resultDict["timestamp"] = Date().timeIntervalSince1970
        
        resultDict["idNumber"] = response.idNumber ?? ""
        resultDict["hologramExists"] = response.hologramExists ?? false
        resultDict["ocrIdAndHologramIdMatch"] = response.ocrIdAndHologramIdMatch ?? false
        resultDict["ocrFaceAndHologramFaceMatch"] = response.ocrFaceAndHologramFaceMatch ?? false
        
        if let hologramImage = response.hologramFaceImage,
           let imageData = hologramImage.jpegData(compressionQuality: 0.8) {
            resultDict["hologramFaceImage"] = imageData.base64EncodedString()
        }
        
        if let error = response.error {
            resultDict["error"] = error.localizedDescription
        }
        
        return resultDict
    }
    
    private func handleDismissOCRCamera(_ result: @escaping FlutterResult) {
        let threadSafeResult = ThreadSafeFlutterResult(result)
        DispatchQueue.main.async { [weak self] in
            if let strongSelf = self, let controller = strongSelf.ocrCameraController {
                controller.dismissOrPopViewController()
            }
            threadSafeResult.send(nil)
        }
    }
    
    private func handleDismissHologramCamera(_ result: @escaping FlutterResult) {
        let threadSafeResult = ThreadSafeFlutterResult(result)
        DispatchQueue.main.async { [weak self] in
            if let strongSelf = self, let controller = strongSelf.hologramCameraController {
                controller.dismissController()
            }
            threadSafeResult.send(nil)
        }
    }

    // MARK: - Standalone IQA

    private func handlePerformIQA(_ call: FlutterMethodCall, result: @escaping FlutterResult) {
        guard let args = call.arguments as? [String: Any] else {
            result(FlutterError(code: "IQA_ERROR", message: "Invalid arguments", details: nil))
            return
        }

        let serverURL = args["serverURL"] as? String ?? ""
        let transactionID = args["transactionID"] as? String ?? ""
        let imageBase64 = args["imageBase64"] as? String ?? ""
        let documentType = args["documentType"] as? String ?? "ID_CARD"
        let documentSide = args["documentSide"] as? String ?? "FRONT"
        let country = args["country"] as? String ?? "TUR"

        guard !imageBase64.isEmpty,
              let imageData = Data(base64Encoded: imageBase64),
              let image = UIImage(data: imageData) else {
            result(FlutterError(code: "IQA_ERROR", message: "Invalid or empty image base64 data", details: nil))
            return
        }

        let ocrDocumentType: OCRDocumentType
        switch documentType.uppercased() {
        case "ID_CARD": ocrDocumentType = .ID_CARD
        case "PASSPORT": ocrDocumentType = .PASSPORT
        case "DRIVER_LICENSE", "DRIVE_LICENCE": ocrDocumentType = .DRIVE_LICENCE
        default: ocrDocumentType = .ID_CARD
        }

        let ocrDocumentSide: OCRDocumentSide
        switch documentSide.uppercased() {
        case "FRONT", "FRONTSIDE": ocrDocumentSide = .frontSide
        case "BACK", "BACKSIDE": ocrDocumentSide = .backSide
        default: ocrDocumentSide = .frontSide
        }

        let ocrCountry = CountryCodeMapper.toCountry(country)

        OCRCameraViewController.performIQA(
            serverURL: serverURL,
            transactionID: transactionID,
            image: image,
            forCountry: ocrCountry,
            forDocumentType: ocrDocumentType,
            forDocumentSide: ocrDocumentSide,
            requestTimeout: 30
        ) { iqaResult in
            // The SDK's network completion is not guaranteed to be on the main thread; Flutter replies must be.
            DispatchQueue.main.async {
                switch iqaResult {
                case .success(let iqaResponse):
                    let resultDict: [String: Any] = [
                        "qualified": iqaResponse.qualified,
                        "displayMessage": iqaResponse.displayMessage ?? "",
                        "rawMessage": iqaResponse.rawMessage ?? "",
                        "documentSide": "\(iqaResponse.documentSide)",
                        "timestamp": Date().timeIntervalSince1970
                    ]
                    result(resultDict)
                case .failure(let error):
                    result(FlutterError(code: OcrFlutterPlugin.sdkErrorCode(error) ?? "IQA_ERROR", message: error.localizedDescription, details: nil))
                }
            }
        }
    }

    // MARK: - Take Photo

    private func handleTakePhoto(_ result: @escaping FlutterResult) {
        DispatchQueue.main.async {
            guard UIImagePickerController.isSourceTypeAvailable(.camera) else {
                result(FlutterError(code: "TAKE_PHOTO_ERROR", message: "Camera not available", details: nil))
                return
            }

            guard let topVC = self.topViewController() else {
                result(FlutterError(code: "TAKE_PHOTO_ERROR", message: "Unable to find view controller", details: nil))
                return
            }

            self.takePhotoResult = result

            let picker = UIImagePickerController()
            picker.sourceType = .camera
            picker.delegate = self
            picker.allowsEditing = false
            topVC.present(picker, animated: true)
        }
    }

    // MARK: - UIImagePickerControllerDelegate

    public func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey : Any]) {
        picker.dismiss(animated: true) {
            if let image = info[.originalImage] as? UIImage,
               let data = image.jpegData(compressionQuality: 0.8) {
                let base64 = data.base64EncodedString()
                self.takePhotoResult?(base64)
            } else {
                self.takePhotoResult?(FlutterError(code: "TAKE_PHOTO_ERROR", message: "Failed to capture photo", details: nil))
            }
            self.takePhotoResult = nil
        }
    }

    public func imagePickerControllerDidCancel(_ picker: UIImagePickerController) {
        picker.dismiss(animated: true) {
            self.takePhotoResult?(FlutterError(code: "TAKE_PHOTO_ERROR", message: "Photo capture cancelled", details: nil))
            self.takePhotoResult = nil
        }
    }
}

// MARK: - OCRCameraControllerDelegate

extension OcrFlutterPlugin: @preconcurrency OCRCameraControllerDelegate, @preconcurrency HologramCameraControllerDelegate {
    
    public func onDocumentScan(for side: UdentifyOCR.OCRDocumentSide, payload: UdentifyOCR.DocumentScanPayload, croppedImages: (front: UIImage?, back: UIImage?)) {
        debugPrint("OcrFlutterPlugin - onDocumentScan called for side: \(side)")
        var scanResult: [String: any Sendable] = [:]
        
        switch side {
        case .frontSide:
            scanResult["documentSide"] = "frontSide"
        case .backSide:
            scanResult["documentSide"] = "backSide"
        case .bothSides:
            scanResult["documentSide"] = "bothSide"
        @unknown default:
            scanResult["documentSide"] = "unknown"
        }
        
        switch payload {
        case .imagePaths(front: let frontPath, back: let backPath):
            // Store paths for later use in performOCR
            self.lastCapturedFrontImagePath = frontPath
            self.lastCapturedBackImagePath = backPath
            
            // SDK paths are internal and cannot be accessed directly
            // Send placeholder to indicate images are stored as paths
            if frontPath != nil {
                scanResult["frontSidePhoto"] = "IMAGE_PATH_STORED"
                debugPrint("OcrFlutterPlugin - Front image path stored for performOCR")
            }
            
            if backPath != nil {
                scanResult["backSidePhoto"] = "IMAGE_PATH_STORED"
                debugPrint("OcrFlutterPlugin - Back image path stored for performOCR")
            }
            
        case .images(front: let frontImage, back: let backImage):
            // Store images for later use
            self.lastCapturedFrontImage = frontImage
            self.lastCapturedBackImage = backImage
            
            // Convert images to base64 for Flutter callback
            if let frontImage = frontImage, let frontData = frontImage.jpegData(compressionQuality: 0.8) {
                scanResult["frontSidePhoto"] = frontData.base64EncodedString()
                debugPrint("OcrFlutterPlugin - Front UIImage converted to base64")
            }
            
            if let backImage = backImage, let backData = backImage.jpegData(compressionQuality: 0.8) {
                scanResult["backSidePhoto"] = backData.base64EncodedString()
                debugPrint("OcrFlutterPlugin - Back UIImage converted to base64")
            }
            
        @unknown default:
            break
        }

        scanResult["timestamp"] = Date().timeIntervalSince1970

        DispatchQueue.main.async { [weak self] in
            self?.ocrCameraController?.dismissOrPopViewController()
            self?.channel?.invokeMethod("onDocumentScan", arguments: scanResult)
        }

        // livenessMode requests the combined OCR+document-liveness flow (see
        // handleStartOCRCamera). The camera controller itself never calls that API (there is
        // no SDK flag to activate it, unlike Android's isDocumentLivenessActive), so trigger it
        // here once every side the configured documentSide needs has been captured, and route
        // the outcome through onOCRAndDocumentLivenessResult/Failure instead of the plain
        // onOCRSuccess/onOCRFailure events.
        if cameraLivenessModeActive && !didTriggerCameraLivenessCheck {
            let frontReady = lastCapturedFrontImage != nil || lastCapturedFrontImagePath != nil
            let backReady = lastCapturedBackImage != nil || lastCapturedBackImagePath != nil
            let captureComplete: Bool
            switch cameraDocumentSide {
            case .frontSide:
                captureComplete = frontReady
            case .backSide:
                captureComplete = backReady
            case .bothSides:
                captureComplete = frontReady && backReady
            @unknown default:
                captureComplete = frontReady || backReady
            }

            if captureComplete {
                didTriggerCameraLivenessCheck = true
                triggerCameraDocumentLiveness()
            }
        }
    }

    /// Runs the combined OCR+document-liveness check against the images captured by the OCR
    /// camera when livenessMode was requested, since OCRCameraViewController never makes that
    /// call itself. Mirrors handlePerformOCRAndDocumentLiveness's own call below.
    private func triggerCameraDocumentLiveness() {
        guard let serverURL = cameraServerURL,
              let transactionID = cameraTransactionID,
              let documentType = cameraDocumentType else {
            return
        }

        let payload: DocumentScanPayload
        if lastCapturedFrontImagePath != nil || lastCapturedBackImagePath != nil {
            payload = .imagePaths(front: lastCapturedFrontImagePath, back: lastCapturedBackImagePath)
        } else {
            payload = .images(front: lastCapturedFrontImage, back: lastCapturedBackImage)
        }

        let country = cameraCountry

        OCRCameraViewController.performOCRAndDocumentLiveness(
            serverURL: serverURL,
            transactionID: transactionID,
            documentPayload: payload,
            country: country,
            documentType: documentType
        ) { [weak self] response in
            DispatchQueue.main.async {
                guard let self = self else { return }

                self.clearStoredData()

                if response.isFailed {
                    self.channel?.invokeMethod("onOCRAndDocumentLivenessFailure", arguments: ["error": "OCR and document liveness check failed"])
                } else {
                    let responseDict = self.convertDocumentLivenessResponseToDict(response, transactionID: transactionID)
                    self.channel?.invokeMethod("onOCRAndDocumentLivenessResult", arguments: responseDict)
                }
            }
        }
    }
    
    public func onIqaResult(for side: UdentifyOCR.OCRDocumentSide, iqaFeedback: UdentifyOCR.IQAFeedback, iqaResponse: UdentifyOCR.IQAResponse?) {
        var iqaResult: [String: any Sendable] = [:]

        switch side {
        case .frontSide:
            iqaResult["documentSide"] = "frontSide"
        case .backSide:
            iqaResult["documentSide"] = "backSide"
        case .bothSides:
            iqaResult["documentSide"] = "bothSides"
        @unknown default:
            iqaResult["documentSide"] = "unknown"
        }

        switch iqaFeedback {
        case .success:
            iqaResult["feedback"] = "success"
            iqaResult["message"] = "Image quality check passed"
        case .blurDetected:
            iqaResult["feedback"] = "blurDetected"
            iqaResult["message"] = "Image is blurry"
        case .glareDetected:
            iqaResult["feedback"] = "glareDetected"
            iqaResult["message"] = "Glare detected on document"
        case .hologramGlare:
            iqaResult["feedback"] = "hologramGlare"
            iqaResult["message"] = "Hologram glare detected which may occlude text"
        case .cardNotDetected:
            iqaResult["feedback"] = "cardNotDetected"
            iqaResult["message"] = "Document not detected in frame"
        case .cardClassificationMismatch:
            iqaResult["feedback"] = "cardClassificationMismatch"
            iqaResult["message"] = "Wrong document type or side"
        case .cardNotIntact:
            iqaResult["feedback"] = "cardNotIntact"
            iqaResult["message"] = "Forgery detected on document"
        case .faceNotDetected:
            iqaResult["feedback"] = "faceNotDetected"
            iqaResult["message"] = "Face not detected on document"
        case .multipleDocumentsDetected:
            iqaResult["feedback"] = "multipleDocumentsDetected"
            iqaResult["message"] = "Multiple documents detected in frame"
        case .chipNotDetected:
            iqaResult["feedback"] = "chipNotDetected"
            iqaResult["message"] = "Chip not detected on document"
        case .signatureNotDetected:
            iqaResult["feedback"] = "signatureNotDetected"
            iqaResult["message"] = "Signature not detected on document"
        case .hiddenPhotoNotDetected:
            iqaResult["feedback"] = "hiddenPhotoNotDetected"
            iqaResult["message"] = "Hidden photo not detected on document"
        case .photoCheatDetected:
            iqaResult["feedback"] = "photoCheatDetected"
            iqaResult["message"] = "Photo tampering detected on document"
        case .modelFailed:
            iqaResult["feedback"] = "modelFailed"
            iqaResult["message"] = "IQA model failed to process the image"
        case .other:
            iqaResult["feedback"] = "other"
            iqaResult["message"] = "Other image quality issues detected"
        @unknown default:
            iqaResult["feedback"] = "unknown"
            iqaResult["message"] = "Unknown IQA feedback"
        }

        if let iqaResponse = iqaResponse {
            iqaResult["qualified"] = iqaResponse.qualified
            iqaResult["displayMessage"] = iqaResponse.displayMessage
            iqaResult["rawMessage"] = iqaResponse.rawMessage
            var checks: [String: Bool] = [:]
            for (checkType, value) in iqaResponse.checks {
                if let value = value {
                    checks[String(describing: checkType)] = value
                }
            }
            iqaResult["checks"] = checks
        }

        iqaResult["timestamp"] = Date().timeIntervalSince1970

        DispatchQueue.main.async { [weak self] in
            self?.channel?.invokeMethod("onIQAResult", arguments: iqaResult)
        }
    }

    public func onOCRDirectiveChanged(directive: UdentifyOCR.OCRDirective) {
        debugPrint("OcrFlutterPlugin - onOCRDirectiveChanged: \(directive.rawValue)")
        DispatchQueue.main.async { [weak self] in
            self?.channel?.invokeMethod("onOCRDirectiveChanged", arguments: [
                "directive": directive.rawValue,
                "timestamp": Date().timeIntervalSince1970
            ])
        }
    }

    public func onHologramDirectiveChanged(directive: UdentifyOCR.HologramDirective) {
        debugPrint("OcrFlutterPlugin - onHologramDirectiveChanged: \(directive.rawValue)")
        DispatchQueue.main.async { [weak self] in
            self?.channel?.invokeMethod("onHologramDirectiveChanged", arguments: [
                "directive": directive.rawValue,
                "timestamp": Date().timeIntervalSince1970
            ])
        }
    }
    
    public func willDismiss(controllerType: ControllerType) {
    }
    
    public func didDismiss(controllerType: ControllerType) {
        // Clear only the controller that was dismissed; the other flow may still be on screen.
        switch controllerType {
        case .OcrViewController: self.ocrCameraController = nil
        case .HologramViewController: self.hologramCameraController = nil
        @unknown default:
            self.ocrCameraController = nil
            self.hologramCameraController = nil
        }
    }
    
    public func onSuccess(response: OCRResponse) {
        debugPrint("OcrFlutterPlugin - onSuccess called")
        let responseDict = convertOCRResponseToDict(response, transactionID: "")
        DispatchQueue.main.async { [weak self] in
            self?.ocrCameraController?.dismissOrPopViewController()
            self?.channel?.invokeMethod("onOCRSuccess", arguments: responseDict)
        }
    }
    
    public func onFailure(error: Error) {
        debugPrint("OcrFlutterPlugin - onFailure called: \(error.localizedDescription)")
        DispatchQueue.main.async { [weak self] in
            guard let self = self else { return }
            // onFailure carries no controller type, so the flow that failed is the one on screen.
            // When neither reference is set the failure cannot be attributed, and both callbacks
            // are notified as before.
            let ocrActive = self.ocrCameraController != nil
            let hologramActive = self.hologramCameraController != nil
            let notifyOCR = ocrActive || !hologramActive
            let notifyHologram = hologramActive || !ocrActive
            self.ocrCameraController?.dismissOrPopViewController()
            self.hologramCameraController?.dismissOrPopViewController()
            if notifyOCR {
                self.channel?.invokeMethod("onOCRFailure", arguments: OcrFlutterPlugin.failureArguments(error))
            }
            if notifyHologram {
                self.channel?.invokeMethod("onHologramFailure", arguments: OcrFlutterPlugin.failureArguments(error))
            }
        }
    }
    
    public func onBackButtonPressed(at controllerType: ControllerType) {
        debugPrint("OcrFlutterPlugin - onBackButtonPressed called for: \(controllerType)")
        DispatchQueue.main.async { [weak self] in
            switch controllerType {
            case .OcrViewController:
                self?.ocrCameraController?.dismissOrPopViewController()
                self?.channel?.invokeMethod("onBackButtonPressed", arguments: nil)
            case .HologramViewController:
                self?.hologramCameraController?.dismissOrPopViewController()
                self?.channel?.invokeMethod("onHologramBackButtonPressed", arguments: nil)
            @unknown default:
                self?.ocrCameraController?.dismissOrPopViewController()
                self?.hologramCameraController?.dismissOrPopViewController()
                self?.channel?.invokeMethod("onBackButtonPressed", arguments: nil)
                self?.channel?.invokeMethod("onHologramBackButtonPressed", arguments: nil)
            }
        }
    }
    
    public func onDestroy(controllerType: ControllerType) {
        DispatchQueue.main.async { [weak self] in
            switch controllerType {
            case .OcrViewController: self?.ocrCameraController = nil
            case .HologramViewController: self?.hologramCameraController = nil
            @unknown default:
                self?.ocrCameraController = nil
                self?.hologramCameraController = nil
            }
        }
    }
    
    public func didFinishOcrAndDocumentLivenessCheck(response: OCRAndDocumentLivenessResponse) {
        debugPrint("OcrFlutterPlugin - didFinishOcrAndDocumentLivenessCheck called")
        let combinedResponse = convertDocumentLivenessResponseToDict(response, transactionID: "")
        DispatchQueue.main.async { [weak self] in
            if response.isFailed {
                self?.channel?.invokeMethod("onOCRAndDocumentLivenessFailure", arguments: ["error": "Document liveness check failed"])
            } else {
                self?.channel?.invokeMethod("onOCRAndDocumentLivenessResult", arguments: combinedResponse)
            }
        }
    }
    
    public func onVideoRecordFinished(videoUrls: [URL]) {
        debugPrint("OcrFlutterPlugin - onVideoRecordFinished called with \(videoUrls.count) videos")
        let urlStrings = videoUrls.map { $0.absoluteString }
        DispatchQueue.main.async { [weak self] in
            self?.channel?.invokeMethod("onHologramVideoRecorded", arguments: ["videoUrls": urlStrings])
        }
    }
}
