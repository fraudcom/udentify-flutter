library ocr_flutter;

export 'src/ocr_flutter_platform_interface.dart';
export 'ocr_flutter_method_channel.dart';

export 'src/constants/document_type.dart';
export 'src/constants/document_side.dart';
export 'src/constants/iqa_feedback.dart';

export 'src/types/ocr_types.dart';
export 'src/types/hologram_types.dart';
export 'src/types/ui_types.dart';
export 'src/types/iqa_types.dart';
export 'src/types/repeat_types.dart';

export 'src/models/ocr_models.dart';

export 'src/events/iqa_events.dart';

import 'src/ocr_flutter_platform_interface.dart';
import 'ocr_flutter_method_channel.dart';
import 'src/models/ocr_models.dart';
import 'src/types/ocr_types.dart';
import 'src/types/hologram_types.dart';
import 'src/types/iqa_types.dart';
import 'src/types/ui_types.dart';
import 'src/types/repeat_types.dart';

/// The main OCR Flutter plugin class
class OcrFlutter {
  static OcrFlutterPlatform get _platform => OcrFlutterPlatform.instance;

  static Future<bool> startOCRCamera(OCRCameraParams params) {
    return _platform.startOCRCamera(params);
  }

  static Future<OCRResponse> performOCR(OCRProcessParams params) {
    return _platform.performOCR(params);
  }

  static Future<bool> startHologramCamera(HologramParams params) {
    return _platform.startHologramCamera(params);
  }

  static Future<HologramResponse> uploadHologramVideo(
      HologramParams params, List<String> videoUrls) {
    return _platform.uploadHologramVideo(params, videoUrls);
  }

  static Future<OCRAndDocumentLivenessResponse> performDocumentLiveness(
      DocumentLivenessParams params) {
    return _platform.performDocumentLiveness(params);
  }

  static Future<OCRAndDocumentLivenessResponse> performOCRAndDocumentLiveness(
      OCRAndDocumentLivenessParams params) {
    return _platform.performOCRAndDocumentLiveness(params);
  }

  /// Opts this app into in-call OCR repeats (the video call operator asks the customer to redo
  /// a document capture without leaving the call), supplying the credentials one would use.
  ///
  /// **Android only, and off by default**; on iOS enable LiveKYC through the video call's
  /// `liveKYCOptions` instead. Pass `null` to opt back out. Call it before starting the video call.
  /// Returns `false` on platforms where it does not apply.
  static Future<bool> setRepeatConfig(OCRRepeatConfig? config) {
    return _platform.setRepeatConfig(config);
  }

  static Future<void> setOCRUIConfig(OCRUIConfig config) {
    return _platform.setOCRUIConfig(config);
  }

  static Future<void> dismissOCRCamera() {
    return _platform.dismissOCRCamera();
  }

  static Future<void> dismissHologramCamera() {
    return _platform.dismissHologramCamera();
  }

  /// Kept for compatibility. The camera only captures (nothing is uploaded until [performOCR]), so the
  /// result of the capture-then-`performOCR` flow is `performOCR`'s return value, not this callback.
  static void setOnOCRSuccessCallback(Function(OCRResponse) callback) {
    MethodChannelOcrFlutter.setOnOCRSuccessCallback(callback);
  }

  static void setOnOCRFailureCallback(Function(String) callback) {
    MethodChannelOcrFlutter.setOnOCRFailureCallback(callback);
  }

  /// Like [setOnOCRFailureCallback] but with the SDK's error name as well (see [OCRFailure]).
  static void setOnOCRErrorCallback(Function(OCRFailure) callback) {
    MethodChannelOcrFlutter.setOnOCRErrorCallback(callback);
  }

  /// Like [setOnOCRAndDocumentLivenessFailureCallback] but with the SDK's error name as well.
  static void setOnOCRAndDocumentLivenessErrorCallback(Function(OCRFailure) callback) {
    MethodChannelOcrFlutter.setOnOCRAndDocumentLivenessErrorCallback(callback);
  }

  /// Like [setOnHologramFailureCallback] but with the SDK's error name as well.
  static void setOnHologramErrorCallback(Function(OCRFailure) callback) {
    MethodChannelOcrFlutter.setOnHologramErrorCallback(callback);
  }

  static void setOnDocumentScanCallback(
      Function(String, String?, String?) callback) {
    MethodChannelOcrFlutter.setOnDocumentScanCallback(callback);
  }

  static void setOnBackButtonPressedCallback(Function() callback) {
    MethodChannelOcrFlutter.setOnBackButtonPressedCallback(callback);
  }

  static void setOnOCRAndDocumentLivenessResultCallback(
      Function(OCRAndDocumentLivenessResponse) callback) {
    MethodChannelOcrFlutter.setOnOCRAndDocumentLivenessResultCallback(callback);
  }

  static void setOnOCRAndDocumentLivenessFailureCallback(
      Function(String) callback) {
    MethodChannelOcrFlutter.setOnOCRAndDocumentLivenessFailureCallback(
        callback);
  }

  static void setOnHologramVideoRecordedCallback(
      Function(List<String>) callback) {
    MethodChannelOcrFlutter.setOnHologramVideoRecordedCallback(callback);
  }

  static void setOnHologramFailureCallback(Function(String) callback) {
    MethodChannelOcrFlutter.setOnHologramFailureCallback(callback);
  }

  static void setOnHologramBackButtonPressedCallback(Function() callback) {
    MethodChannelOcrFlutter.setOnHologramBackButtonPressedCallback(callback);
  }

  static Future<Map<String, dynamic>> performIQA({
    required String serverURL,
    required String transactionID,
    required String imageBase64,
    required String documentType,
    required String documentSide,
    String country = 'TUR',
  }) {
    return _platform.performIQA(
      serverURL: serverURL,
      transactionID: transactionID,
      imageBase64: imageBase64,
      documentType: documentType,
      documentSide: documentSide,
      country: country,
    );
  }

  static Future<String> takePhoto() {
    return _platform.takePhoto();
  }

  static void setOnOCRDirectiveChangedCallback(Function(String, double) callback) {
    MethodChannelOcrFlutter.setOnOCRDirectiveChangedCallback(callback);
  }

  static void setOnHologramDirectiveChangedCallback(Function(String, double) callback) {
    MethodChannelOcrFlutter.setOnHologramDirectiveChangedCallback(callback);
  }

  /// Register a callback for IQA results, including the per-check map
  /// (photoCheatSatisfied, chipExistenceSatisfied, ...).
  static void setOnIQAResultCallback(Function(IQAResult) callback) {
    MethodChannelOcrFlutter.setOnIQAResultCallback(callback);
  }

  static void clearOCRCallbacks() {
    MethodChannelOcrFlutter.clearAllCallbacks();
  }
}
